package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.battery.SurvivalThreshold
import com.example.ui.ConsoleTab
import com.example.ui.TriageViewModel
import com.example.ui.components.AcousticRadarDialog
import com.example.ui.components.BatteryDutyCycleDialog
import com.example.ui.components.InjectBeaconDialog
import com.example.ui.screens.DataMuleScreen
import com.example.ui.screens.OfflineGisMapScreen
import com.example.ui.screens.RubbleRadarScreen
import com.example.ui.screens.TriageDashboardScreen
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {
    private val viewModel: TriageViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                RescuerConsoleApp(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RescuerConsoleApp(viewModel: TriageViewModel) {
    val currentTab by viewModel.currentTab.collectAsState()
    val bleState by viewModel.bleState.collectAsState()
    val batteryState by viewModel.batteryState.collectAsState()
    val acousticState by viewModel.acousticState.collectAsState()

    val showInjectDialog by viewModel.showInjectBeaconDialog.collectAsState()
    val showBatteryDialog by viewModel.showBatteryDutyCycleDialog.collectAsState()
    val showAcousticDialog by viewModel.showAcousticRadarDialog.collectAsState()

    val threshold = batteryState.threshold
    val thresholdColor by animateColorAsState(targetValue = threshold.primaryColor, label = "thresholdColor")

    // Runtime Permission Launcher for BLE & Location
    val permissionsToRequest = buildList {
        add(Manifest.permission.ACCESS_FINE_LOCATION)
        add(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            add(Manifest.permission.BLUETOOTH_SCAN)
            add(Manifest.permission.BLUETOOTH_ADVERTISE)
            add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.NEARBY_WIFI_DEVICES)
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        // Permissions evaluated, app continues in offline fallback mode if denied
    }

    LaunchedEffect(Unit) {
        permissionLauncher.launch(permissionsToRequest.toTypedArray())
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("rescuer_console_scaffold"),
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            Column {
                TopAppBar(
                    title = {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "RESCUER CONSOLE",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Black,
                                    color = TacticalCyan,
                                    letterSpacing = 1.1.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(threshold.containerColor)
                                        .border(1.dp, thresholdColor, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 5.dp, vertical = 1.dp)
                                ) {
                                    Text(
                                        text = if (batteryState.isDutyCycleActive) "15M DUTY CYCLE" else "OFF-GRID",
                                        color = thresholdColor,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                            Text(
                                text = "NDRF/SDRF Incident Hub • P2P Mesh • MBTiles GIS",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                fontSize = 9.sp
                            )
                        }
                    },
                    actions = {
                        // 1. Hands-Free Acoustic Geiger Radar Chip
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (acousticState.isEnabled) Color(0x2B00E5FF) else TacticalSurface)
                                .border(1.dp, if (acousticState.isEnabled) CyanAccent else BorderStroke, RoundedCornerShape(16.dp))
                                .clickable { viewModel.openAcousticRadarDialog() }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                .testTag("top_bar_acoustic_radar_chip"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (acousticState.isEnabled) Icons.Default.GraphicEq else Icons.Default.HearingDisabled,
                                contentDescription = "Acoustic Radar",
                                tint = if (acousticState.isEnabled) CyanAccent else TextSecondary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (acousticState.isEnabled) "${acousticState.currentFrequencyHz}Hz" else "Geiger",
                                color = if (acousticState.isEnabled) CyanAccent else TextSecondary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        // 2. Hardware Battery Monitor Chip (Color-coded by survival threshold)
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(threshold.containerColor)
                                .border(1.dp, thresholdColor, RoundedCornerShape(16.dp))
                                .clickable { viewModel.openBatteryDutyCycleDialog() }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                .testTag("top_bar_battery_chip"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (batteryState.isCharging) Icons.Default.BatteryChargingFull else Icons.Default.BatteryStd,
                                contentDescription = "Battery Status",
                                tint = thresholdColor,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "${batteryState.activePercentage}%",
                                color = thresholdColor,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        // 3. Inject Emergency Beacon Action Button
                        IconButton(
                            onClick = { viewModel.openInjectDialog() },
                            modifier = Modifier
                                .size(34.dp)
                                .testTag("top_bar_btn_inject")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddAlert,
                                contentDescription = "Inject Emergency Beacon",
                                tint = TacticalCyan,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        // 4. BLE Continuous Scanner Engine Toggle
                        IconButton(
                            onClick = { viewModel.bleScanningEngine.toggleScanning() },
                            modifier = Modifier
                                .size(34.dp)
                                .testTag("top_bar_btn_toggle_scan")
                        ) {
                            Icon(
                                imageVector = if (bleState.isScanning) Icons.Default.Sensors else Icons.Default.SensorsOff,
                                contentDescription = "Toggle BLE Scanning",
                                tint = if (bleState.isScanning) TacticalCyan else UrgentAmber,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = TacticalDarkBg,
                        titleContentColor = TacticalCyan
                    )
                )

                // Duty Cycling Alert Strip (When <20% Critical Red is Active)
                if (batteryState.isDutyCycleActive) {
                    val isSleeping = batteryState.isDeepSleeping
                    val stripColor = if (isSleeping) Color(0xFFD50000) else Color(0xFF00C853)
                    val minutes = batteryState.secondsRemainingInCurrentCycle / 60
                    val seconds = batteryState.secondsRemainingInCurrentCycle % 60

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(stripColor.copy(alpha = 0.2f))
                            .border(width = 0.5.dp, color = stripColor)
                            .padding(horizontal = 12.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isSleeping) Icons.Default.Bedtime else Icons.Default.Bolt,
                                contentDescription = null,
                                tint = stripColor,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isSleeping)
                                    "15-MIN DEEP SLEEP ACTIVE • NEXT WAKE IN %02d:%02d".format(minutes, seconds)
                                else
                                    "30S RAPID RADIO TRIAGE BURST • %02d SEC LEFT".format(seconds),
                                color = stripColor,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Text(
                            text = "AlarmManager WAKEUP",
                            color = TextSecondary,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = TacticalDarkBg,
                tonalElevation = 4.dp,
                modifier = Modifier
                    .border(width = 1.dp, color = TacticalBorder)
                    .testTag("console_navigation_bar")
            ) {
                // 1. Incident Command Triage Dashboard (QoS)
                NavigationBarItem(
                    selected = currentTab == ConsoleTab.TRIAGE_DASHBOARD,
                    onClick = { viewModel.setTab(ConsoleTab.TRIAGE_DASHBOARD) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.FormatListNumbered,
                            contentDescription = "Triage Dashboard"
                        )
                    },
                    label = { Text("Triage QoS", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF00363D),
                        selectedTextColor = TacticalCyan,
                        indicatorColor = TacticalCyan,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    ),
                    modifier = Modifier.testTag("nav_item_triage_dashboard")
                )

                // 2. Tactical Offline GIS Navigation (.mbtiles)
                NavigationBarItem(
                    selected = currentTab == ConsoleTab.OFFLINE_GIS,
                    onClick = { viewModel.setTab(ConsoleTab.OFFLINE_GIS) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Navigation,
                            contentDescription = "Offline GIS"
                        )
                    },
                    label = { Text("Tactical GIS", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF00363D),
                        selectedTextColor = TacticalCyan,
                        indicatorColor = TacticalCyan,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    ),
                    modifier = Modifier.testTag("nav_item_offline_gis")
                )

                // 3. Rubble Radar Micro-Localization (2.4 GHz + Acoustic Geiger)
                NavigationBarItem(
                    selected = currentTab == ConsoleTab.RUBBLE_RADAR,
                    onClick = { viewModel.setTab(ConsoleTab.RUBBLE_RADAR) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Radar,
                            contentDescription = "Rubble Radar"
                        )
                    },
                    label = { Text("Rubble Radar", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF00363D),
                        selectedTextColor = TacticalCyan,
                        indicatorColor = TacticalCyan,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    ),
                    modifier = Modifier.testTag("nav_item_rubble_radar")
                )

                // 4. Data Mule P2P_CLUSTER Console
                NavigationBarItem(
                    selected = currentTab == ConsoleTab.DATA_MULE,
                    onClick = { viewModel.setTab(ConsoleTab.DATA_MULE) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Data Mule P2P"
                        )
                    },
                    label = { Text("Data Mule", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF00363D),
                        selectedTextColor = TacticalCyan,
                        indicatorColor = TacticalCyan,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    ),
                    modifier = Modifier.testTag("nav_item_data_mule")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                ConsoleTab.TRIAGE_DASHBOARD -> TriageDashboardScreen(viewModel = viewModel)
                ConsoleTab.OFFLINE_GIS -> OfflineGisMapScreen(viewModel = viewModel)
                ConsoleTab.RUBBLE_RADAR -> RubbleRadarScreen(viewModel = viewModel)
                ConsoleTab.DATA_MULE -> DataMuleScreen(viewModel = viewModel)
            }
        }

        // Test Packet Injector Dialog
        if (showInjectDialog) {
            InjectBeaconDialog(
                onDismiss = { viewModel.closeInjectDialog() },
                onInject = { count, isTrapped, hasBleed, isInsulin, isO2, isSupply, sector ->
                    viewModel.injectSimulatedBeacon(
                        survivorCount = count,
                        isTrapped = isTrapped,
                        hasSevereBleed = hasBleed,
                        isInsulinLow = isInsulin,
                        isOxygenLow = isO2,
                        isStrandedSupply = isSupply,
                        sector = sector
                    )
                }
            )
        }

        // Hardware Battery & 15-Minute Duty Cycle Dialog
        if (showBatteryDialog) {
            BatteryDutyCycleDialog(
                batteryState = batteryState,
                onDismiss = { viewModel.closeBatteryDutyCycleDialog() },
                onSetSimulatedPct = { viewModel.hardwareBatteryMonitor.setSimulatedPercentage(it) },
                onResetHardware = { viewModel.hardwareBatteryMonitor.resetToHardwareBattery() },
                onForceWakeBurst = { viewModel.hardwareBatteryMonitor.forceWakeBurstNow() },
                onForceSleep = { viewModel.hardwareBatteryMonitor.forceSleepNow() },
                onArmDutyCycle = { viewModel.hardwareBatteryMonitor.armAutomatedDutyCycling() },
                onDisarmDutyCycle = { viewModel.hardwareBatteryMonitor.disarmDutyCycling() }
            )
        }

        // Hands-Free Acoustic Geiger Radar Proximity Dialog
        if (showAcousticDialog) {
            AcousticRadarDialog(
                acousticState = acousticState,
                onDismiss = { viewModel.closeAcousticRadarDialog() },
                onToggleEnabled = { viewModel.acousticRadarAudioEngine.toggleEnabled() },
                onSetVolume = { viewModel.acousticRadarAudioEngine.setVolume(it) },
                onToggleMute = { viewModel.acousticRadarAudioEngine.toggleMute() },
                onTriggerTestPip = { viewModel.acousticRadarAudioEngine.triggerSingleTestBeep() },
                onUpdateRssi = { viewModel.acousticRadarAudioEngine.updateLiveRssi(it) }
            )
        }
    }
}
