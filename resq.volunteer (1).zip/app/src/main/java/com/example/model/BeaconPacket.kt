package com.example.model

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest

/**
 * Urgency QoS Triage Levels:
 * Level 1: Life-safety critical (Trapped under rubble, severe hemorrhage, 3+ cluster) -> Preempts all
 * Level 2: Urgent medical depletion (Insulin or Oxygen depletion, trauma)
 * Level 3: Stranded supply requests, non-critical check-ins
 */
enum class TriageLevel(val code: Int, val label: String) {
    LEVEL_1(1, "LEVEL 1 - CRITICAL LIFE SAFETY"),
    LEVEL_2(2, "LEVEL 2 - URGENT MEDICAL"),
    LEVEL_3(3, "LEVEL 3 - STRANDED SUPPLY")
}

enum class RescueStatus(val label: String) {
    UNASSIGNED("Unassigned"),
    TRIAGE_EN_ROUTE("Rescuer En Route"),
    EXTRACTED("Surface Extracted"),
    EVACUATED("Evacuated to Base HQ")
}

data class TraumaFlags(
    val isTrappedUnderRubble: Boolean = false,
    val hasSevereHemorrhage: Boolean = false,
    val isClusterThreePlus: Boolean = false,
    val isInsulinDepleted: Boolean = false,
    val isOxygenDepleted: Boolean = false,
    val isStrandedSupply: Boolean = false,
    val hasCrushInjury: Boolean = false,
    val requiresCanineSearch: Boolean = false
) {
    fun toBitmask(): Int {
        var mask = 0
        if (isTrappedUnderRubble) mask = mask or (1 shl 0)
        if (hasSevereHemorrhage) mask = mask or (1 shl 1)
        if (isClusterThreePlus) mask = mask or (1 shl 2)
        if (isInsulinDepleted) mask = mask or (1 shl 3)
        if (isOxygenDepleted) mask = mask or (1 shl 4)
        if (isStrandedSupply) mask = mask or (1 shl 5)
        if (hasCrushInjury) mask = mask or (1 shl 6)
        if (requiresCanineSearch) mask = mask or (1 shl 7)
        return mask
    }

    companion object {
        fun fromBitmask(mask: Int): TraumaFlags {
            return TraumaFlags(
                isTrappedUnderRubble = (mask and (1 shl 0)) != 0,
                hasSevereHemorrhage = (mask and (1 shl 1)) != 0,
                isClusterThreePlus = (mask and (1 shl 2)) != 0,
                isInsulinDepleted = (mask and (1 shl 3)) != 0,
                isOxygenDepleted = (mask and (1 shl 4)) != 0,
                isStrandedSupply = (mask and (1 shl 5)) != 0,
                hasCrushInjury = (mask and (1 shl 6)) != 0,
                requiresCanineSearch = (mask and (1 shl 7)) != 0
            )
        }
    }
}

/**
 * 30-byte connectionless emergency payload broadcast via BLE (Manufacturer ID: 0xFFFF).
 */
data class BeaconPacket(
    val manufacturerId: Int = 0xFFFF,
    val protocolVersion: Int = 1,
    val survivorId: String, // e.g., "VIC-7412"
    val survivorCount: Int,
    val flags: TraumaFlags,
    val latitude: Double,
    val longitude: Double,
    val altitudeMeters: Float,
    val ttl: Int, // Time-to-Live counter
    val hopCount: Int, // Number of hops relayed
    val timestampSeconds: Long,
    val batteryPercent: Int,
    val relayNodeName: String = "Direct",
    val rssi: Int = -72,
    val rawPayloadHex: String = "",
    val sha256Hash: String = ""
) {
    /**
     * Calculates Disaster Priority QoS Level based on strict life-safety parameters:
     * Level 1 preempts all others:
     * - Individuals trapped under rubble
     * - Victims suffering severe hemorrhaging
     * - Clusters of 3 or more people
     */
    val triageLevel: TriageLevel
        get() = when {
            flags.isTrappedUnderRubble || flags.hasSevereHemorrhage || survivorCount >= 3 || flags.isClusterThreePlus -> TriageLevel.LEVEL_1
            flags.isInsulinDepleted || flags.isOxygenDepleted || flags.hasCrushInjury -> TriageLevel.LEVEL_2
            else -> TriageLevel.LEVEL_3
        }

    /**
     * Re-broadcast packet: decrements TTL and increments hop count.
     */
    fun forwardMultiHop(forwarderName: String = "Responder-Console"): BeaconPacket? {
        if (ttl <= 1) return null
        return this.copy(
            ttl = ttl - 1,
            hopCount = hopCount + 1,
            relayNodeName = forwarderName
        )
    }

    companion object {
        const val EMERGENCY_MANUFACTURER_ID = 0xFFFF
        const val BUZZER_COMMAND_MANUFACTURER_ID = 0xFFEE
        const val PACKET_SIZE = 30

        /**
         * Calculates SHA-256 string for packet deduplication
         */
        fun computeSha256(bytes: ByteArray): String {
            val md = MessageDigest.getInstance("SHA-256")
            val digest = md.digest(bytes)
            return digest.joinToString("") { "%02x".format(it) }
        }

        /**
         * Encodes a BeaconPacket into standard 30-byte connectionless emergency frame
         */
        fun encode(packet: BeaconPacket): ByteArray {
            val buffer = ByteBuffer.allocate(PACKET_SIZE).order(ByteOrder.LITTLE_ENDIAN)
            buffer.putShort(EMERGENCY_MANUFACTURER_ID.toShort()) // Byte 0-1
            buffer.put(packet.protocolVersion.toByte()) // Byte 2
            
            // 4-byte victim ID hash
            val idBytes = packet.survivorId.toByteArray().take(4).toByteArray()
            val paddedId = ByteArray(4)
            System.arraycopy(idBytes, 0, paddedId, 0, idBytes.size.coerceAtMost(4))
            buffer.put(paddedId) // Byte 3-6
            
            buffer.put(packet.survivorCount.coerceIn(1, 255).toByte()) // Byte 7
            buffer.put(packet.flags.toBitmask().toByte()) // Byte 8
            
            // Fixed-point coordinates (micro-degrees * 10)
            buffer.putInt((packet.latitude * 1e6).toInt()) // Byte 9-12
            buffer.putInt((packet.longitude * 1e6).toInt()) // Byte 13-16
            buffer.putShort(packet.altitudeMeters.toInt().toShort()) // Byte 17-18
            buffer.put(packet.ttl.coerceIn(0, 15).toByte()) // Byte 19
            buffer.put(packet.hopCount.coerceIn(0, 255).toByte()) // Byte 20
            
            // Epoch seconds (last 4 bytes)
            val sec = (packet.timestampSeconds and 0xFFFFFFFFL).toInt()
            buffer.putInt(sec) // Byte 21-24
            buffer.put(packet.batteryPercent.coerceIn(0, 100).toByte()) // Byte 25
            
            // Padding / Checksum (4 bytes)
            buffer.putInt(0xAA55AA55.toInt()) // Byte 26-29
            return buffer.array()
        }

        /**
         * Decodes a 30-byte raw payload
         */
        fun decode(bytes: ByteArray, rssi: Int = -70, relayOrigin: String = "Direct"): BeaconPacket? {
            if (bytes.size < PACKET_SIZE) return null
            return try {
                val buffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
                val mfgId = buffer.short.toInt() and 0xFFFF
                if (mfgId != EMERGENCY_MANUFACTURER_ID) return null
                
                val version = buffer.get().toInt() and 0xFF
                val idBytes = ByteArray(4)
                buffer.get(idBytes)
                val survivorId = "VIC-" + idBytes.joinToString("") { "%02X".format(it) }.take(4)
                
                val count = buffer.get().toInt() and 0xFF
                val flagsMask = buffer.get().toInt() and 0xFF
                val flags = TraumaFlags.fromBitmask(flagsMask)
                
                val latRaw = buffer.int
                val lonRaw = buffer.int
                val lat = latRaw / 1e6
                val lon = lonRaw / 1e6
                
                val alt = buffer.short.toFloat()
                val ttl = buffer.get().toInt() and 0xFF
                val hops = buffer.get().toInt() and 0xFF
                val sec = buffer.int.toLong() and 0xFFFFFFFFL
                val battery = buffer.get().toInt() and 0xFF
                
                val hash = computeSha256(bytes)
                val hexString = bytes.joinToString("") { "%02X".format(it) }
                
                BeaconPacket(
                    manufacturerId = mfgId,
                    protocolVersion = version,
                    survivorId = survivorId,
                    survivorCount = count.coerceAtLeast(1),
                    flags = flags,
                    latitude = lat,
                    longitude = lon,
                    altitudeMeters = alt,
                    ttl = ttl,
                    hopCount = hops,
                    timestampSeconds = sec,
                    batteryPercent = battery,
                    relayNodeName = relayOrigin,
                    rssi = rssi,
                    rawPayloadHex = hexString,
                    sha256Hash = hash
                )
            } catch (e: Exception) {
                null
            }
        }
    }
}
