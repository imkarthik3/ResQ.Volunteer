package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [BeaconEntity::class, DataMuleSyncEntity::class],
    version = 1,
    exportSchema = false
)
abstract class TriageDatabase : RoomDatabase() {
    abstract fun beaconDao(): BeaconDao
    abstract fun dataMuleDao(): DataMuleDao

    companion object {
        @Volatile
        private var INSTANCE: TriageDatabase? = null

        fun getDatabase(context: Context): TriageDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    TriageDatabase::class.java,
                    "triage_console_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
