package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.BeaconPacket
import com.example.model.RescueStatus
import com.example.model.TraumaFlags
import com.example.model.TriageLevel

@Entity(tableName = "beacons")
data class BeaconEntity(
    @PrimaryKey
    val hash: String, // SHA-256 deduplication key
    val survivorId: String,
    val survivorCount: Int,
    val triageLevelCode: Int,
    val isTrappedUnderRubble: Boolean,
    val hasSevereHemorrhage: Boolean,
    val isClusterThreePlus: Boolean,
    val isInsulinDepleted: Boolean,
    val isOxygenDepleted: Boolean,
    val isStrandedSupply: Boolean,
    val hasCrushInjury: Boolean,
    val requiresCanineSearch: Boolean,
    val latitude: Double,
    val longitude: Double,
    val altitudeMeters: Float,
    val ttl: Int,
    val hopCount: Int,
    val relayNodeName: String,
    val timestampSeconds: Long,
    val batteryPercent: Int,
    val rssi: Int,
    val sector: String,
    val status: String = RescueStatus.UNASSIGNED.name,
    val rawPayloadHex: String,
    val isForwarded: Boolean = false,
    val forwardedAtMillis: Long = 0L,
    val receivedAtMillis: Long = System.currentTimeMillis()
) {
    fun toBeaconPacket(): BeaconPacket {
        val flags = TraumaFlags(
            isTrappedUnderRubble = isTrappedUnderRubble,
            hasSevereHemorrhage = hasSevereHemorrhage,
            isClusterThreePlus = isClusterThreePlus,
            isInsulinDepleted = isInsulinDepleted,
            isOxygenDepleted = isOxygenDepleted,
            isStrandedSupply = isStrandedSupply,
            hasCrushInjury = hasCrushInjury,
            requiresCanineSearch = requiresCanineSearch
        )
        return BeaconPacket(
            survivorId = survivorId,
            survivorCount = survivorCount,
            flags = flags,
            latitude = latitude,
            longitude = longitude,
            altitudeMeters = altitudeMeters,
            ttl = ttl,
            hopCount = hopCount,
            timestampSeconds = timestampSeconds,
            batteryPercent = batteryPercent,
            relayNodeName = relayNodeName,
            rssi = rssi,
            rawPayloadHex = rawPayloadHex,
            sha256Hash = hash
        )
    }

    val triageLevel: TriageLevel
        get() = when (triageLevelCode) {
            1 -> TriageLevel.LEVEL_1
            2 -> TriageLevel.LEVEL_2
            else -> TriageLevel.LEVEL_3
        }

    val rescueStatus: RescueStatus
        get() = try {
            RescueStatus.valueOf(status)
        } catch (e: Exception) {
            RescueStatus.UNASSIGNED
        }

    companion object {
        fun fromPacket(packet: BeaconPacket, sector: String = "Sector Alpha"): BeaconEntity {
            return BeaconEntity(
                hash = packet.sha256Hash,
                survivorId = packet.survivorId,
                survivorCount = packet.survivorCount,
                triageLevelCode = packet.triageLevel.code,
                isTrappedUnderRubble = packet.flags.isTrappedUnderRubble,
                hasSevereHemorrhage = packet.flags.hasSevereHemorrhage,
                isClusterThreePlus = packet.flags.isClusterThreePlus,
                isInsulinDepleted = packet.flags.isInsulinDepleted,
                isOxygenDepleted = packet.flags.isOxygenDepleted,
                isStrandedSupply = packet.flags.isStrandedSupply,
                hasCrushInjury = packet.flags.hasCrushInjury,
                requiresCanineSearch = packet.flags.requiresCanineSearch,
                latitude = packet.latitude,
                longitude = packet.longitude,
                altitudeMeters = packet.altitudeMeters,
                ttl = packet.ttl,
                hopCount = packet.hopCount,
                relayNodeName = packet.relayNodeName,
                timestampSeconds = packet.timestampSeconds,
                batteryPercent = packet.batteryPercent,
                rssi = packet.rssi,
                sector = sector,
                status = RescueStatus.UNASSIGNED.name,
                rawPayloadHex = packet.rawPayloadHex,
                isForwarded = false,
                forwardedAtMillis = 0L,
                receivedAtMillis = System.currentTimeMillis()
            )
        }
    }
}

@Entity(tableName = "data_mule_sync_logs")
data class DataMuleSyncEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val peerId: String,
    val peerName: String,
    val peerType: String,
    val packetsExchanged: Int,
    val missingMerged: Int,
    val timestampMillis: Long = System.currentTimeMillis(),
    val status: String = "SYNCHRONIZED"
)
