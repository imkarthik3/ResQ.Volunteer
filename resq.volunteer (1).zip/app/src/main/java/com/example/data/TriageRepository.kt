package com.example.data

import android.content.Context
import com.example.model.BeaconPacket
import com.example.model.RescueStatus
import com.example.model.TraumaFlags
import com.example.model.TriageLevel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class TriageRepository(
    private val beaconDao: BeaconDao,
    private val dataMuleDao: DataMuleDao
) {
    val allBeacons: Flow<List<BeaconEntity>> = beaconDao.getAllBeaconsFlow()
    val allSyncLogs: Flow<List<DataMuleSyncEntity>> = dataMuleDao.getAllSyncLogsFlow()
    private val mutex = Mutex()

    /**
     * Intercepts a 30-byte beacon packet:
     * - Performs SHA-256 deduplication check against SQLite DB.
     * - If NEW and TTL > 1: schedules for multi-hop re-broadcast for 15 seconds.
     * Returns true if packet was newly inserted, false if duplicate.
     */
    suspend fun interceptPacket(packet: BeaconPacket, sector: String = "Sector Alpha"): Boolean = mutex.withLock {
        val existing = beaconDao.getByHash(packet.sha256Hash)
        if (existing != null) {
            return false // Deduplicated by SHA-256
        }
        val entity = BeaconEntity.fromPacket(packet, sector)
        beaconDao.insertBeacon(entity)
        return true
    }

    suspend fun updateRescueStatus(hash: String, status: RescueStatus) {
        beaconDao.updateStatus(hash, status.name)
    }

    suspend fun markAsForwarded(hash: String) {
        beaconDao.markAsForwarded(hash, System.currentTimeMillis())
    }

    suspend fun getPendingForwardBeacons(): List<BeaconEntity> {
        return beaconDao.getPendingForwardBeacons()
    }

    suspend fun getAllHashes(): List<String> {
        return beaconDao.getAllHashes()
    }

    /**
     * Executes high-speed differential database merge with a peer data mule console
     */
    suspend fun executeDifferentialMerge(
        peerId: String,
        peerName: String,
        peerType: String,
        incomingBeacons: List<BeaconEntity>
    ): Int = mutex.withLock {
        val localHashes = beaconDao.getAllHashes().toSet()
        val missingRecords = incomingBeacons.filter { it.hash !in localHashes }
        if (missingRecords.isNotEmpty()) {
            beaconDao.insertBeacons(missingRecords)
        }
        dataMuleDao.insertSyncLog(
            DataMuleSyncEntity(
                peerId = peerId,
                peerName = peerName,
                peerType = peerType,
                packetsExchanged = incomingBeacons.size,
                missingMerged = missingRecords.size,
                timestampMillis = System.currentTimeMillis(),
                status = "SYNCHRONIZED"
            )
        )
        return missingRecords.size
    }

    /**
     * Seeds realistic disaster scenario telemetry across collapsed sectors
     */
    suspend fun seedInitialDisasterTelemetryIfEmpty() {
        val existing = allBeacons.firstOrNull()
        if (existing.isNullOrEmpty()) {
            val baseTime = System.currentTimeMillis() / 1000 - 180

            // Sector Alpha: Collapsed Shopping Plaza (Level 1 Entrapment)
            val p1 = BeaconPacket(
                survivorId = "VIC-8841",
                survivorCount = 4,
                flags = TraumaFlags(
                    isTrappedUnderRubble = true,
                    hasSevereHemorrhage = true,
                    isClusterThreePlus = true,
                    requiresCanineSearch = true
                ),
                latitude = 28.6139,
                longitude = 77.2090,
                altitudeMeters = -3.2f, // 3.2m subterranean void
                ttl = 4,
                hopCount = 0,
                timestampSeconds = baseTime + 120,
                batteryPercent = 38,
                relayNodeName = "Direct",
                rssi = -61
            )

            // Sector Bravo: Riverbank Landslide (Level 1 Arterial Hemorrhage)
            val p2 = BeaconPacket(
                survivorId = "VIC-3910",
                survivorCount = 1,
                flags = TraumaFlags(
                    isTrappedUnderRubble = true,
                    hasSevereHemorrhage = true,
                    hasCrushInjury = true
                ),
                latitude = 28.6155,
                longitude = 77.2115,
                altitudeMeters = 0.5f,
                ttl = 3,
                hopCount = 1,
                timestampSeconds = baseTime + 90,
                batteryPercent = 21,
                relayNodeName = "Relayed: NDRF-Canine-2",
                rssi = -78
            )

            // Sector Charlie: Metro Station Concourse (Level 2 Medical: Insulin & Oxygen)
            val p3 = BeaconPacket(
                survivorId = "VIC-6124",
                survivorCount = 2,
                flags = TraumaFlags(
                    isInsulinDepleted = true,
                    isOxygenDepleted = true
                ),
                latitude = 28.6120,
                longitude = 77.2075,
                altitudeMeters = -8.5f,
                ttl = 2,
                hopCount = 2,
                timestampSeconds = baseTime + 45,
                batteryPercent = 54,
                relayNodeName = "Relayed: SDRF-Mule-4",
                rssi = -82
            )

            // Sector Delta: East Residential Zone (Level 3: Stranded Clean Water / Food)
            val p4 = BeaconPacket(
                survivorId = "VIC-1092",
                survivorCount = 2,
                flags = TraumaFlags(
                    isStrandedSupply = true
                ),
                latitude = 28.6168,
                longitude = 77.2060,
                altitudeMeters = 2.0f,
                ttl = 5,
                hopCount = 0,
                timestampSeconds = baseTime + 160,
                batteryPercent = 76,
                relayNodeName = "Direct",
                rssi = -71
            )

            // Sector Alpha: Basement Parking Cavity (Level 1: 3+ Cluster)
            val p5 = BeaconPacket(
                survivorId = "VIC-9403",
                survivorCount = 5,
                flags = TraumaFlags(
                    isTrappedUnderRubble = true,
                    isClusterThreePlus = true
                ),
                latitude = 28.6131,
                longitude = 77.2084,
                altitudeMeters = -4.0f,
                ttl = 4,
                hopCount = 1,
                timestampSeconds = baseTime + 175,
                batteryPercent = 42,
                relayNodeName = "Relayed: Vol-Mesh-Alpha",
                rssi = -58
            )

            val raw1 = BeaconPacket.encode(p1)
            val raw2 = BeaconPacket.encode(p2)
            val raw3 = BeaconPacket.encode(p3)
            val raw4 = BeaconPacket.encode(p4)
            val raw5 = BeaconPacket.encode(p5)

            val b1 = p1.copy(sha256Hash = BeaconPacket.computeSha256(raw1), rawPayloadHex = raw1.joinToString("") { "%02X".format(it) })
            val b2 = p2.copy(sha256Hash = BeaconPacket.computeSha256(raw2), rawPayloadHex = raw2.joinToString("") { "%02X".format(it) })
            val b3 = p3.copy(sha256Hash = BeaconPacket.computeSha256(raw3), rawPayloadHex = raw3.joinToString("") { "%02X".format(it) })
            val b4 = p4.copy(sha256Hash = BeaconPacket.computeSha256(raw4), rawPayloadHex = raw4.joinToString("") { "%02X".format(it) })
            val b5 = p5.copy(sha256Hash = BeaconPacket.computeSha256(raw5), rawPayloadHex = raw5.joinToString("") { "%02X".format(it) })

            beaconDao.insertBeacons(
                listOf(
                    BeaconEntity.fromPacket(b1, "Sector Alpha (Plaza Collapse)"),
                    BeaconEntity.fromPacket(b2, "Sector Bravo (Riverbank Void)"),
                    BeaconEntity.fromPacket(b3, "Sector Charlie (Metro Tunnel)"),
                    BeaconEntity.fromPacket(b4, "Sector Delta (Residential)"),
                    BeaconEntity.fromPacket(b5, "Sector Alpha (Basement Cavity)")
                )
            )

            // Seed initial Data Mule Sync Audit
            dataMuleDao.insertSyncLog(
                DataMuleSyncEntity(
                    peerId = "CANINE-K9-02",
                    peerName = "Canine Search Team Bravo",
                    peerType = "CANINE_TEAM",
                    packetsExchanged = 8,
                    missingMerged = 2,
                    timestampMillis = System.currentTimeMillis() - 420000,
                    status = "SYNCHRONIZED"
                )
            )
            dataMuleDao.insertSyncLog(
                DataMuleSyncEntity(
                    peerId = "NDRF-BOAT-07",
                    peerName = "NDRF Rescue Boat Sector-2",
                    peerType = "BOAT",
                    packetsExchanged = 14,
                    missingMerged = 5,
                    timestampMillis = System.currentTimeMillis() - 180000,
                    status = "SYNCHRONIZED"
                )
            )
        }
    }
}
