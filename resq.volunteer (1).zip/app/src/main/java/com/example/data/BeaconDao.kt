package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface BeaconDao {
    @Query("SELECT * FROM beacons ORDER BY triageLevelCode ASC, survivorCount DESC, receivedAtMillis DESC")
    fun getAllBeaconsFlow(): Flow<List<BeaconEntity>>

    @Query("SELECT * FROM beacons WHERE hash = :hash LIMIT 1")
    suspend fun getByHash(hash: String): BeaconEntity?

    @Query("SELECT hash FROM beacons")
    suspend fun getAllHashes(): List<String>

    @Query("SELECT * FROM beacons WHERE isForwarded = 0 AND ttl > 1")
    suspend fun getPendingForwardBeacons(): List<BeaconEntity>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertBeacon(beacon: BeaconEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertBeacons(beacons: List<BeaconEntity>): List<Long>

    @Update
    suspend fun updateBeacon(beacon: BeaconEntity)

    @Query("UPDATE beacons SET status = :status WHERE hash = :hash")
    suspend fun updateStatus(hash: String, status: String)

    @Query("UPDATE beacons SET isForwarded = 1, forwardedAtMillis = :timeMillis WHERE hash = :hash")
    suspend fun markAsForwarded(hash: String, timeMillis: Long)

    @Query("DELETE FROM beacons")
    suspend fun clearAll()
}

@Dao
interface DataMuleDao {
    @Query("SELECT * FROM data_mule_sync_logs ORDER BY timestampMillis DESC")
    fun getAllSyncLogsFlow(): Flow<List<DataMuleSyncEntity>>

    @Insert
    suspend fun insertSyncLog(log: DataMuleSyncEntity): Long

    @Query("SELECT COUNT(*) FROM data_mule_sync_logs")
    suspend fun getSyncCount(): Int
}
