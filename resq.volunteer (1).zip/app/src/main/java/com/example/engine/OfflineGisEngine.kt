package com.example.engine

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import com.example.data.BeaconEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.*

data class TacticalMapFeature(
    val id: String,
    val name: String,
    val type: String, // "COLLAPSE_ZONE", "RUBBLE_PILE", "FLOOD_ZONE", "SAFE_CORRIDOR", "BASE_CAMP"
    val centerLat: Double,
    val centerLon: Double,
    val radiusMeters: Float
)

data class CompassVector(
    val rescuerHeadingDegrees: Float = 0f,
    val targetBearingDegrees: Float = 0f,
    val headingDeltaDegrees: Float = 0f, // Relative angle: positive = turn right, negative = turn left
    val distanceMeters: Float = 0f,
    val isAlignedWithinFiveDegrees: Boolean = false,
    val cardinalDirection: String = "N"
)

data class OfflineGisState(
    val rescuerLat: Double = 28.6135,
    val rescuerLon: Double = 77.2085,
    val rescuerHeadingDegrees: Float = 45f,
    val selectedSurvivor: BeaconEntity? = null,
    val compassVector: CompassVector = CompassVector(),
    val offlineTileCacheName: String = "osm_disaster_theatre_v4.mbtiles",
    val offlineTileSizeBytes: Long = 184549376L, // ~176 MB pre-bundled vector tiles
    val mapZoomLevel: Float = 16.5f,
    val tacticalFeatures: List<TacticalMapFeature> = emptyList()
)

class OfflineGisEngine(
    private val context: Context,
    private val scope: CoroutineScope
) : SensorEventListener {

    private val _state = MutableStateFlow(OfflineGisState())
    val state: StateFlow<OfflineGisState> = _state.asStateFlow()

    private val sensorManager: SensorManager? =
        context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private val rotationSensor: Sensor? =
        sensorManager?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
            ?: sensorManager?.getDefaultSensor(Sensor.TYPE_ORIENTATION)

    private val rotationMatrix = FloatArray(9)
    private val orientationAngles = FloatArray(3)
    private var smoothedHeading = 0f

    init {
        loadTacticalDisasterGeometry()
        registerCompassSensor()
    }

    private fun loadTacticalDisasterGeometry() {
        val features = listOf(
            TacticalMapFeature(
                id = "FEATURE-1",
                name = "NDRF Field Forward Command Post",
                type = "BASE_CAMP",
                centerLat = 28.6130,
                centerLon = 77.2080,
                radiusMeters = 35f
            ),
            TacticalMapFeature(
                id = "FEATURE-2",
                name = "Sector Alpha Structural Collapse Perimeter",
                type = "COLLAPSE_ZONE",
                centerLat = 28.6140,
                centerLon = 77.2090,
                radiusMeters = 85f
            ),
            TacticalMapFeature(
                id = "FEATURE-3",
                name = "River Yamuna Overflow / Flash Mud Line",
                type = "FLOOD_ZONE",
                centerLat = 28.6158,
                centerLon = 77.2120,
                radiusMeters = 110f
            ),
            TacticalMapFeature(
                id = "FEATURE-4",
                name = "Metro Underground Tunnel Fault Cavity",
                type = "RUBBLE_PILE",
                centerLat = 28.6120,
                centerLon = 77.2075,
                radiusMeters = 65f
            ),
            TacticalMapFeature(
                id = "FEATURE-5",
                name = "Reinforced Evacuation Corridor Bravo",
                type = "SAFE_CORRIDOR",
                centerLat = 28.6135,
                centerLon = 77.2082,
                radiusMeters = 200f
            )
        )
        _state.value = _state.value.copy(tacticalFeatures = features)
    }

    fun selectSurvivorMarker(survivor: BeaconEntity?) {
        _state.value = _state.value.copy(selectedSurvivor = survivor)
        recomputeCompassVector()
    }

    fun updateRescuerCoordinates(lat: Double, lon: Double) {
        _state.value = _state.value.copy(rescuerLat = lat, rescuerLon = lon)
        recomputeCompassVector()
    }

    private fun registerCompassSensor() {
        rotationSensor?.let { sensor ->
            sensorManager?.registerListener(this, sensor, SensorManager.SENSOR_DELAY_UI)
        }
    }

    fun unregisterCompassSensor() {
        sensorManager?.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null) return
        if (event.sensor.type == Sensor.TYPE_ROTATION_VECTOR) {
            SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
            SensorManager.getOrientation(rotationMatrix, orientationAngles)
            var azimuthDegrees = Math.toDegrees(orientationAngles[0].toDouble()).toFloat()
            if (azimuthDegrees < 0) azimuthDegrees += 360f

            // Low-pass filter for smooth magnetic compass needle
            val alpha = 0.15f
            smoothedHeading = (alpha * azimuthDegrees + (1 - alpha) * smoothedHeading + 360f) % 360f
            _state.value = _state.value.copy(rescuerHeadingDegrees = smoothedHeading)
            recomputeCompassVector()
        } else if (event.sensor.type == Sensor.TYPE_ORIENTATION) {
            val azimuth = (event.values[0] + 360f) % 360f
            smoothedHeading = (0.15f * azimuth + 0.85f * smoothedHeading + 360f) % 360f
            _state.value = _state.value.copy(rescuerHeadingDegrees = smoothedHeading)
            recomputeCompassVector()
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun recomputeCompassVector() {
        val target = _state.value.selectedSurvivor ?: return
        val rLat = _state.value.rescuerLat
        val rLon = _state.value.rescuerLon
        val heading = _state.value.rescuerHeadingDegrees

        val bearing = calculateBearing(rLat, rLon, target.latitude, target.longitude)
        val distance = calculateHaversineDistance(rLat, rLon, target.latitude, target.longitude)

        // Heading delta: relative bearing
        var delta = (bearing - heading) % 360f
        if (delta > 180f) delta -= 360f
        if (delta < -180f) delta += 360f

        val aligned = abs(delta) <= 5.0f
        val cardinal = degreesToCardinal(bearing)

        _state.value = _state.value.copy(
            compassVector = CompassVector(
                rescuerHeadingDegrees = heading,
                targetBearingDegrees = bearing,
                headingDeltaDegrees = delta,
                distanceMeters = distance,
                isAlignedWithinFiveDegrees = aligned,
                cardinalDirection = cardinal
            )
        )
    }

    companion object {
        /**
         * Calculates initial bearing from point 1 to point 2 in degrees (0..360)
         */
        fun calculateBearing(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Float {
            val φ1 = Math.toRadians(lat1)
            val φ2 = Math.toRadians(lat2)
            val Δλ = Math.toRadians(lon2 - lon1)

            val y = sin(Δλ) * cos(φ2)
            val x = cos(φ1) * sin(φ2) - sin(φ1) * cos(φ2) * cos(Δλ)
            val θ = atan2(y, x)
            val bearing = (Math.toDegrees(θ) + 360.0) % 360.0
            return bearing.toFloat()
        }

        /**
         * Calculates straight-line distance in meters using Haversine formula
         */
        fun calculateHaversineDistance(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Float {
            val r = 6371000.0 // Earth radius in meters
            val dLat = Math.toRadians(lat2 - lat1)
            val dLon = Math.toRadians(lon2 - lon1)
            val a = sin(dLat / 2).pow(2.0) +
                    cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                    sin(dLon / 2).pow(2.0)
            val c = 2 * atan2(sqrt(a), sqrt(1 - a))
            return (r * c).toFloat()
        }

        fun degreesToCardinal(degrees: Float): String {
            val directions = arrayOf("N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW")
            val index = ((degrees + 11.25f) / 22.5f).toInt() % 16
            return directions[index]
        }
    }
}
