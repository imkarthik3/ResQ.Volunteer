package com.example.engine

import android.content.Context
import android.os.Vibrator
import android.os.VibrationEffect
import android.os.Build
import com.example.data.BeaconEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.pow
import kotlin.random.Random

enum class PhysicalDebrisZone(
    val title: String,
    val distanceDescription: String,
    val minDbm: Int,
    val maxDbm: Int,
    val urgencyColorHex: Long
) {
    ZONE_DEEP(
        title = "DEEP / DISTANT CAVITY",
        distanceDescription = "10 to 15 meters through heavy debris / reinforced concrete",
        minDbm = -90,
        maxDbm = -80,
        urgencyColorHex = 0xFFFF9100 // Amber
    ),
    ZONE_APPROACHING(
        title = "APPROACHING VOID",
        distanceDescription = "3 to 8 meters approaching void pocket",
        minDbm = -79,
        maxDbm = -65,
        urgencyColorHex = 0xFFFF5722 // Deep Orange
    ),
    ZONE_SURFACE_EXTRACTION(
        title = "IMMEDIATE EXTRACTION PERIMETER",
        distanceDescription = "Within 2 meters - Pinpoint surface extraction perimeter",
        minDbm = -64,
        maxDbm = -45,
        urgencyColorHex = 0xFFFF1744 // Critical Red
    ),
    ZONE_OUT_OF_RANGE(
        title = "FAINT / BEYOND DETECTION",
        distanceDescription = "Exceeds 15m or blocked by dense lead/water barrier",
        minDbm = -100,
        maxDbm = -91,
        urgencyColorHex = 0xFF546E7A // Muted Slate
    )
}

data class RubbleRadarState(
    val targetSurvivor: BeaconEntity? = null,
    val rawRssiDbm: Float = -76f,
    val filteredEmaDbm: Float = -76f,
    val estimatedMeters: Float = 5.2f,
    val currentZone: PhysicalDebrisZone = PhysicalDebrisZone.ZONE_APPROACHING,
    val isTracking: Boolean = false,
    val rssiHistory: List<Float> = emptyList(),
    val isBuzzerStrobeActive: Boolean = false,
    val buzzerSecondsRemaining: Int = 0,
    val lastCommandTransmittedHex: String = "",
    val multipathJitterFilterAlpha: Float = 0.22f
)

class RubbleRadarEngine(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private val _state = MutableStateFlow(RubbleRadarState())
    val state: StateFlow<RubbleRadarState> = _state.asStateFlow()

    private var trackingJob: Job? = null
    private var buzzerJob: Job? = null
    private val historyPoints = ArrayDeque<Float>(30)

    fun selectTargetSurvivor(beacon: BeaconEntity) {
        val initialRssi = beacon.rssi.toFloat().coerceIn(-95f, -45f)
        historyPoints.clear()
        repeat(15) { historyPoints.add(initialRssi) }

        _state.value = _state.value.copy(
            targetSurvivor = beacon,
            rawRssiDbm = initialRssi,
            filteredEmaDbm = initialRssi,
            estimatedMeters = rssiToEstimatedDistance(initialRssi),
            currentZone = calculateZone(initialRssi),
            rssiHistory = historyPoints.toList(),
            isTracking = true
        )
        startRadarSimulationLoop()
    }

    fun setFilterAlpha(newAlpha: Float) {
        _state.value = _state.value.copy(multipathJitterFilterAlpha = newAlpha.coerceIn(0.05f, 0.95f))
    }

    private fun startRadarSimulationLoop() {
        trackingJob?.cancel()
        trackingJob = scope.launch(Dispatchers.Default) {
            var currentEma = _state.value.filteredEmaDbm
            while (isActive) {
                delay(350) // High-frequency 2.4 GHz radio pulse sampling
                val currentTarget = _state.value.targetSurvivor ?: break

                // Simulate realistic multipath signal fading & concrete slab attenuation fluctuations
                val baseLevel = currentTarget.rssi.toFloat()
                val multipathJitter = Random.nextFloat() * 8f - 4f
                val rawSample = (baseLevel + multipathJitter).coerceIn(-98f, -42f)

                // Exponential Moving Average (EMA) algorithm: EMA_t = alpha * RSSI_raw + (1 - alpha) * EMA_{t-1}
                val alpha = _state.value.multipathJitterFilterAlpha
                currentEma = alpha * rawSample + (1f - alpha) * currentEma

                synchronized(historyPoints) {
                    if (historyPoints.size >= 25) {
                        historyPoints.removeFirst()
                    }
                    historyPoints.add(currentEma)
                }

                val zone = calculateZone(currentEma)
                val dist = rssiToEstimatedDistance(currentEma)

                _state.value = _state.value.copy(
                    rawRssiDbm = rawSample,
                    filteredEmaDbm = currentEma,
                    estimatedMeters = dist,
                    currentZone = zone,
                    rssiHistory = synchronized(historyPoints) { historyPoints.toList() }
                )
            }
        }
    }

    /**
     * Translates raw/filtered decibel-milliwatts into clear physical zones
     */
    private fun calculateZone(dbm: Float): PhysicalDebrisZone {
        return when {
            dbm >= -64f -> PhysicalDebrisZone.ZONE_SURFACE_EXTRACTION
            dbm >= -79f -> PhysicalDebrisZone.ZONE_APPROACHING
            dbm >= -90f -> PhysicalDebrisZone.ZONE_DEEP
            else -> PhysicalDebrisZone.ZONE_OUT_OF_RANGE
        }
    }

    /**
     * Log-distance path loss model calibrated for 2.4 GHz signal propagation through rubble
     */
    private fun rssiToEstimatedDistance(rssiDbm: Float): Float {
        val txPower = -50f // 1m reference power
        val pathLossExponent = 3.8f // Heavy concrete / structural debris factor
        val ratio = (txPower - rssiDbm) / (10f * pathLossExponent)
        val rawDist = 10.0.pow(ratio.toDouble()).toFloat()
        return (rawDist * 10f).toInt() / 10f
    }

    /**
     * Transmits an authenticated BLE command packet (0xFFEE) that triggers the buried phone's
     * internal alarm buzzer at maximum gain and strobes the camera LED!
     */
    fun transmitAcousticOpticalTrigger() {
        val target = _state.value.targetSurvivor ?: return

        // 0xFFEE authenticated payload construction:
        // Byte 0-1: 0xFFEE
        // Byte 2-5: Target Victim ID
        // Byte 6: 0x03 (Trigger buzzer + LED Strobe)
        // Byte 7: 0x1E (30 seconds duration)
        // Byte 8-11: Rescuer Auth Nonce
        val victimHex = target.survivorId.replace("-", "").take(4).padEnd(4, '0')
        val commandHex = "FFEE" + victimHex + "031E" + "A7F39C21"

        // Trigger tactical haptics on rescuer console
        triggerHapticConfirmation()

        _state.value = _state.value.copy(
            isBuzzerStrobeActive = true,
            buzzerSecondsRemaining = 30,
            lastCommandTransmittedHex = commandHex
        )

        buzzerJob?.cancel()
        buzzerJob = scope.launch(Dispatchers.Default) {
            for (sec in 30 downTo 1) {
                _state.value = _state.value.copy(buzzerSecondsRemaining = sec)
                delay(1000)
            }
            _state.value = _state.value.copy(
                isBuzzerStrobeActive = false,
                buzzerSecondsRemaining = 0
            )
        }
    }

    private fun triggerHapticConfirmation() {
        try {
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            if (vibrator != null && vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val effect = VibrationEffect.createWaveform(
                        longArrayOf(0, 150, 100, 250),
                        intArrayOf(0, 255, 0, 255),
                        -1
                    )
                    vibrator.vibrate(effect)
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(300)
                }
            }
        } catch (e: Exception) {
            // Ignore if vibration unavailable
        }
    }

    fun stopTracking() {
        trackingJob?.cancel()
        _state.value = _state.value.copy(isTracking = false)
    }
}
