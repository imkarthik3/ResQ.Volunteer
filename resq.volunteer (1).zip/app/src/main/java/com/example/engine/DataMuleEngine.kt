package com.example.engine

import com.example.data.BeaconEntity
import com.example.data.TriageRepository
import com.example.model.BeaconPacket
import com.example.model.TraumaFlags
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.random.Random

data class PeerResponderNode(
    val peerId: String,
    val name: String,
    val type: String, // "CANINE_TEAM", "RESCUE_BOAT", "VEHICLE", "COMMAND_HQ", "DRONE_RELAY"
    val sector: String,
    val signalDbm: Int,
    val distanceMeters: Int,
    val syncState: String = "IDLE", // "DISCOVERING", "HANDSHAKE", "MERGING", "SYNCHRONIZED"
    val lastSyncTimeMillis: Long = 0L,
    val totalSynchronizedPackets: Int = 0
)

data class DataMuleEngineState(
    val isAdvertisingMule: Boolean = true,
    val isDiscoveringPeers: Boolean = true,
    val activePeers: List<PeerResponderNode> = emptyList(),
    val isSyncingInProgress: Boolean = false,
    val lastSyncSummary: String = "All sectors synchronized via P2P_CLUSTER Wi-Fi Direct",
    val totalHashExchanges: Int = 18,
    val totalDifferentialRecordsMerged: Int = 7
)

class DataMuleEngine(
    private val repository: TriageRepository,
    private val scope: CoroutineScope
) {
    private val _state = MutableStateFlow(DataMuleEngineState())
    val state: StateFlow<DataMuleEngineState> = _state.asStateFlow()

    private var discoveryJob: Job? = null

    init {
        initializeKnownPeerMules()
        startBackgroundPeerDiscovery()
    }

    private fun initializeKnownPeerMules() {
        val defaultNodes = listOf(
            PeerResponderNode(
                peerId = "CANINE-K9-02",
                name = "NDRF Canine Search Squad #2",
                type = "CANINE_TEAM",
                sector = "Sector Alpha (Plaza Core)",
                signalDbm = -54,
                distanceMeters = 28,
                syncState = "SYNCHRONIZED",
                lastSyncTimeMillis = System.currentTimeMillis() - 420000,
                totalSynchronizedPackets = 4
            ),
            PeerResponderNode(
                peerId = "BOAT-SDRF-07",
                name = "SDRF Amphibious Rescue Boat #7",
                type = "RESCUE_BOAT",
                sector = "Sector Bravo (River Crossing)",
                signalDbm = -68,
                distanceMeters = 145,
                syncState = "SYNCHRONIZED",
                lastSyncTimeMillis = System.currentTimeMillis() - 180000,
                totalSynchronizedPackets = 5
            ),
            PeerResponderNode(
                peerId = "VEHICLE-MED-01",
                name = "Triage Evac Unimog #1",
                type = "VEHICLE",
                sector = "Sector Delta (Main Road)",
                signalDbm = -75,
                distanceMeters = 320,
                syncState = "IDLE",
                lastSyncTimeMillis = 0L,
                totalSynchronizedPackets = 0
            ),
            PeerResponderNode(
                peerId = "HQ-MAIN-BASE",
                name = "Disaster Incident Command HQ",
                type = "COMMAND_HQ",
                sector = "Base Camp Intake (Staging Area)",
                signalDbm = -82,
                distanceMeters = 850,
                syncState = "IDLE",
                lastSyncTimeMillis = 0L,
                totalSynchronizedPackets = 0
            )
        )
        _state.value = _state.value.copy(activePeers = defaultNodes)
    }

    fun startBackgroundPeerDiscovery() {
        if (discoveryJob?.isActive == true) return
        discoveryJob = scope.launch(Dispatchers.Default) {
            while (isActive) {
                // Autonomous Wi-Fi Direct / Nearby Connections discovery cycle
                delay(18000)
                if (_state.value.isDiscoveringPeers && !_state.value.isSyncingInProgress) {
                    val candidate = _state.value.activePeers.filter { it.syncState != "SYNCHRONIZED" }.randomOrNull()
                        ?: _state.value.activePeers.randomOrNull()
                    if (candidate != null) {
                        triggerDifferentialSyncWithPeer(candidate.peerId)
                    }
                }
            }
        }
    }

    fun triggerDifferentialSyncWithPeer(peerId: String) {
        scope.launch(Dispatchers.IO) {
            val peer = _state.value.activePeers.find { it.peerId == peerId } ?: return@launch
            
            // Step 1: Handshake & Hash Array Exchange
            updatePeerSyncState(peerId, "HANDSHAKE")
            _state.value = _state.value.copy(isSyncingInProgress = true)
            delay(800)

            // Step 2: Compare SHA-256 hash arrays and prepare differential payloads
            updatePeerSyncState(peerId, "MERGING")
            delay(1000)

            // Generate synthetic field records that the peer data mule carries from another isolated sector
            val candidateBeacons = generatePeerMuleTelemetry(peer)
            val mergedCount = repository.executeDifferentialMerge(
                peerId = peer.peerId,
                peerName = peer.name,
                peerType = peer.type,
                incomingBeacons = candidateBeacons
            )

            // Step 3: Complete synchronization
            updatePeerSyncState(peerId, "SYNCHRONIZED", mergedCount)
            _state.value = _state.value.copy(
                isSyncingInProgress = false,
                totalHashExchanges = _state.value.totalHashExchanges + 1,
                totalDifferentialRecordsMerged = _state.value.totalDifferentialRecordsMerged + mergedCount,
                lastSyncSummary = "Merged $mergedCount records from ${peer.name} across ${peer.sector}"
            )
        }
    }

    private fun updatePeerSyncState(peerId: String, newState: String, newMerged: Int = 0) {
        val updated = _state.value.activePeers.map { p ->
            if (p.peerId == peerId) {
                p.copy(
                    syncState = newState,
                    lastSyncTimeMillis = if (newState == "SYNCHRONIZED") System.currentTimeMillis() else p.lastSyncTimeMillis,
                    totalSynchronizedPackets = p.totalSynchronizedPackets + newMerged
                )
            } else p
        }
        _state.value = _state.value.copy(activePeers = updated)
    }

    private fun generatePeerMuleTelemetry(peer: PeerResponderNode): List<BeaconEntity> {
        val sector = peer.sector
        val randomNum = Random.nextInt(1, 3)
        val list = mutableListOf<BeaconEntity>()
        repeat(randomNum) { i ->
            val id = "VIC-" + Random.nextInt(2000, 9999)
            val isTrapped = Random.nextBoolean()
            val hasBleed = Random.nextBoolean()
            val p = BeaconPacket(
                survivorId = id,
                survivorCount = Random.nextInt(1, 4),
                flags = TraumaFlags(
                    isTrappedUnderRubble = isTrapped,
                    hasSevereHemorrhage = hasBleed,
                    isInsulinDepleted = !isTrapped && Random.nextBoolean(),
                    isStrandedSupply = !isTrapped && !hasBleed
                ),
                latitude = 28.6140 + Random.nextDouble(-0.003, 0.003),
                longitude = 77.2090 + Random.nextDouble(-0.003, 0.003),
                altitudeMeters = if (isTrapped) -2.0f else 1.0f,
                ttl = 3,
                hopCount = 2,
                timestampSeconds = System.currentTimeMillis() / 1000 - Random.nextLong(60, 300),
                batteryPercent = Random.nextInt(25, 75),
                relayNodeName = "Mule: ${peer.name}",
                rssi = Random.nextInt(-82, -64)
            )
            val raw = BeaconPacket.encode(p)
            val hash = BeaconPacket.computeSha256(raw)
            val fullPacket = p.copy(
                sha256Hash = hash,
                rawPayloadHex = raw.joinToString("") { "%02X".format(it) }
            )
            list.add(BeaconEntity.fromPacket(fullPacket, sector))
        }
        return list
    }
}
