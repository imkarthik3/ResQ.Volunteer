package com.example.engine.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin

data class AcousticRadarState(
    val isEnabled: Boolean = false,
    val currentRssiDbm: Int = -74,
    val currentFrequencyHz: Int = 1302,
    val currentIntervalMs: Long = 1265L,
    val beepsPerMinute: Int = 47,
    val volume: Float = 0.85f,
    val isMuted: Boolean = false,
    val isAudioTrackReady: Boolean = false,
    val lastBeepTimestamp: Long = 0L,
    val isPipFlashing: Boolean = false
)

class AcousticRadarAudioEngine(
    private val scope: CoroutineScope
) {
    private val _state = MutableStateFlow(AcousticRadarState())
    val state: StateFlow<AcousticRadarState> = _state.asStateFlow()

    private var audioTrack: AudioTrack? = null
    private var playbackJob: Job? = null

    private val sampleRate = 44100
    private val beepDurationMs = 35

    init {
        initAudioTrack()
    }

    @Synchronized
    private fun initAudioTrack() {
        try {
            val minBufferSize = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            val bufferSize = (minBufferSize * 2).coerceAtLeast(sampleRate / 4)

            audioTrack = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                AudioTrack(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build(),
                    AudioFormat.Builder()
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .build(),
                    bufferSize,
                    AudioTrack.MODE_STREAM,
                    AudioManager.AUDIO_SESSION_ID_GENERATE
                )
            } else {
                @Suppress("DEPRECATION")
                AudioTrack(
                    AudioManager.STREAM_ALARM,
                    sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufferSize,
                    AudioTrack.MODE_STREAM
                )
            }

            audioTrack?.play()
            _state.value = _state.value.copy(isAudioTrackReady = true)
            Log.i("AcousticRadar", "AudioTrack initialized successfully in STREAM mode at $sampleRate Hz")
        } catch (e: Exception) {
            Log.e("AcousticRadar", "Failed to initialize AudioTrack", e)
            _state.value = _state.value.copy(isAudioTrackReady = false)
        }
    }

    /**
     * Converts live Bluetooth Low Energy ScanResult.rssi into hands-free Geiger-style dynamic beeps:
     * - Scaling continuously from slow 800 Hz tones every 1.8 seconds (1800 ms) at -85 dBm
     * - To rapid 2400 Hz alerts every 100 ms at -50 dBm
     */
    fun updateLiveRssi(rssi: Int) {
        val freq = calculateFrequencyForRssi(rssi)
        val interval = calculateIntervalForRssi(rssi)
        val bpm = if (interval > 0) (60000L / interval).toInt() else 600

        _state.value = _state.value.copy(
            currentRssiDbm = rssi,
            currentFrequencyHz = freq,
            currentIntervalMs = interval,
            beepsPerMinute = bpm
        )
    }

    fun setEnabled(enabled: Boolean) {
        if (_state.value.isEnabled == enabled) return
        _state.value = _state.value.copy(isEnabled = enabled)

        if (enabled) {
            startAudioPlaybackLoop()
        } else {
            stopAudioPlaybackLoop()
        }
    }

    fun toggleEnabled() {
        setEnabled(!_state.value.isEnabled)
    }

    fun setVolume(volume: Float) {
        val clamped = volume.coerceIn(0f, 1f)
        _state.value = _state.value.copy(volume = clamped)
        audioTrack?.setVolume(clamped)
    }

    fun toggleMute() {
        val newMute = !_state.value.isMuted
        _state.value = _state.value.copy(isMuted = newMute)
        audioTrack?.setVolume(if (newMute) 0f else _state.value.volume)
    }

    private fun startAudioPlaybackLoop() {
        playbackJob?.cancel()
        playbackJob = scope.launch(Dispatchers.Default) {
            if (audioTrack == null || audioTrack?.state != AudioTrack.STATE_INITIALIZED) {
                initAudioTrack()
            }
            try {
                audioTrack?.play()
            } catch (e: Exception) {
                Log.w("AcousticRadar", "AudioTrack play error", e)
            }

            while (isActive && _state.value.isEnabled) {
                val currentFreq = _state.value.currentFrequencyHz
                val intervalMs = _state.value.currentIntervalMs
                val isMuted = _state.value.isMuted
                val volume = _state.value.volume

                if (!isMuted && volume > 0f) {
                    playSynthesizedPcmBeep(currentFreq, volume)
                }

                // Trigger visual pip pulse
                _state.value = _state.value.copy(
                    lastBeepTimestamp = System.currentTimeMillis(),
                    isPipFlashing = true
                )

                scope.launch {
                    delay(60)
                    _state.value = _state.value.copy(isPipFlashing = false)
                }

                // Sleep between pips
                val sleepDuration = (intervalMs - beepDurationMs).coerceAtLeast(15L)
                delay(sleepDuration)
            }
        }
    }

    private fun stopAudioPlaybackLoop() {
        playbackJob?.cancel()
        _state.value = _state.value.copy(isPipFlashing = false)
    }

    /**
     * Synthesizes 16-bit PCM mono audio buffers directly into AudioTrack with cosine smoothing envelope
     */
    private fun playSynthesizedPcmBeep(freq: Int, volume: Float) {
        val track = audioTrack ?: return
        if (track.state != AudioTrack.STATE_INITIALIZED) return

        val numSamples = (sampleRate * (beepDurationMs / 1000.0)).toInt()
        val pcmBuffer = ShortArray(numSamples)
        val attackDecaySamples = (sampleRate * 0.005).toInt().coerceAtLeast(1) // 5ms fade envelope

        for (i in 0 until numSamples) {
            val angle = 2.0 * PI * freq * i / sampleRate
            val rawSine = sin(angle)

            // Envelope to prevent speaker click
            val envelope = when {
                i < attackDecaySamples -> i.toFloat() / attackDecaySamples
                i > numSamples - attackDecaySamples -> (numSamples - i).toFloat() / attackDecaySamples
                else -> 1.0f
            }

            val sampleValue = (rawSine * envelope * volume * Short.MAX_VALUE).toInt()
            pcmBuffer[i] = sampleValue.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }

        try {
            track.write(pcmBuffer, 0, pcmBuffer.size)
        } catch (e: Exception) {
            Log.e("AcousticRadar", "AudioTrack write error", e)
        }
    }

    fun triggerSingleTestBeep() {
        scope.launch(Dispatchers.Default) {
            playSynthesizedPcmBeep(_state.value.currentFrequencyHz, _state.value.volume)
        }
    }

    fun release() {
        stopAudioPlaybackLoop()
        try {
            audioTrack?.stop()
            audioTrack?.release()
        } catch (e: Exception) {
            // Ignore
        }
        audioTrack = null
    }

    companion object {
        private const val MIN_DBM = -85f
        private const val MAX_DBM = -50f
        private const val MIN_FREQ = 800f
        private const val MAX_FREQ = 2400f
        private const val MAX_INTERVAL_MS = 1800f
        private const val MIN_INTERVAL_MS = 100f

        fun calculateFrequencyForRssi(rssi: Int): Int {
            val ratio = ((rssi.toFloat() - MIN_DBM) / (MAX_DBM - MIN_DBM)).coerceIn(0f, 1f)
            return (MIN_FREQ + ratio * (MAX_FREQ - MIN_FREQ)).toInt()
        }

        fun calculateIntervalForRssi(rssi: Int): Long {
            val ratio = ((rssi.toFloat() - MIN_DBM) / (MAX_DBM - MIN_DBM)).coerceIn(0f, 1f)
            return (MAX_INTERVAL_MS - ratio * (MAX_INTERVAL_MS - MIN_INTERVAL_MS)).toLong()
        }
    }
}
