package com.example.engine.battery

import androidx.compose.ui.graphics.Color

enum class SurvivalThreshold(
    val label: String,
    val rangeDescription: String,
    val colorHex: Long,
    val primaryColor: Color,
    val containerColor: Color,
    val borderColor: Color,
    val textColor: Color
) {
    EMERALD_GREEN(
        label = "ENDURANCE OPTIMAL",
        rangeDescription = "≥ 50% Battery Endurance",
        colorHex = 0xFF00E676,
        primaryColor = Color(0xFF00E676),
        containerColor = Color(0x1F00E676),
        borderColor = Color(0x6600E676),
        textColor = Color(0xFFB9F6CA)
    ),
    WARNING_AMBER(
        label = "POWER CONSERVATION",
        rangeDescription = "20–49% Battery Warning",
        colorHex = 0xFFFFB300,
        primaryColor = Color(0xFFFFB300),
        containerColor = Color(0x1FFFFB300),
        borderColor = Color(0x66FFB300),
        textColor = Color(0xFFFFE082)
    ),
    CRITICAL_RED(
        label = "SURVIVAL DEEP-SLEEP",
        rangeDescription = "< 20% Automated 15-min Duty Cycling",
        colorHex = 0xFFFF1744,
        primaryColor = Color(0xFFFF1744),
        containerColor = Color(0x2BFF1744),
        borderColor = Color(0x80FF1744),
        textColor = Color(0xFFFF8A80)
    );

    companion object {
        fun fromBatteryPercentage(levelPercent: Int): SurvivalThreshold {
            return when {
                levelPercent >= 50 -> EMERALD_GREEN
                levelPercent in 20..49 -> WARNING_AMBER
                else -> CRITICAL_RED
            }
        }
    }
}
