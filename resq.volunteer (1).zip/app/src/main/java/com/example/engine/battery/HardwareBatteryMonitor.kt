package com.example.engine.battery

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.SystemClock
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class BatteryMonitorState(
    val realHardwarePercentage: Int = 82,
    val activePercentage: Int = 82,
    val isSimulatedOverride: Boolean = false,
    val voltageMv: Int = 4120,
    val temperatureCelsius: Float = 29.4f,
    val isCharging: Boolean = false,
    val threshold: SurvivalThreshold = SurvivalThreshold.EMERALD_GREEN,
    // Duty Cycling via AlarmManager (< 20% Critical Red)
    val isDutyCycleActive: Boolean = false,
    val isDeepSleeping: Boolean = false,
    val isAwakeBurst: Boolean = true,
    val secondsRemainingInCurrentCycle: Int = 0,
    val totalCyclesCompleted: Int = 0,
    val lastWakeupTimestampMillis: Long = System.currentTimeMillis()
)

class HardwareBatteryMonitor(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private val _state = MutableStateFlow(BatteryMonitorState())
    val state: StateFlow<BatteryMonitorState> = _state.asStateFlow()

    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
    private var countdownJob: Job? = null

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_BATTERY_CHANGED) {
                val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                val voltage = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
                val temp = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
                val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                        status == BatteryManager.BATTERY_STATUS_FULL

                val pct = if (level >= 0 && scale > 0) {
                    (level * 100) / scale
                } else 78

                updateHardwareReadings(pct, voltage, temp, isCharging)
            }
        }
    }

    init {
        instance = this
        registerBatteryReceiver()
        startCycleTicker()
    }

    private fun registerBatteryReceiver() {
        try {
            val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val initial = context.registerReceiver(batteryReceiver, filter)
            if (initial != null) {
                batteryReceiver.onReceive(context, initial)
            }
        } catch (e: Exception) {
            Log.e("BatteryMonitor", "Error registering battery receiver", e)
            // Fallback initial values
            updateHardwareReadings(76, 4050, 28.5f, false)
        }
    }

    fun unregister() {
        try {
            context.unregisterReceiver(batteryReceiver)
        } catch (e: Exception) {
            // Ignore
        }
        cancelAlarmManagerSchedule()
        countdownJob?.cancel()
    }

    private fun updateHardwareReadings(pct: Int, voltage: Int, temp: Float, isCharging: Boolean) {
        val currentSim = _state.value.isSimulatedOverride
        val effectivePct = if (currentSim) _state.value.activePercentage else pct
        val threshold = SurvivalThreshold.fromBatteryPercentage(effectivePct)

        _state.value = _state.value.copy(
            realHardwarePercentage = pct,
            activePercentage = effectivePct,
            voltageMv = voltage,
            temperatureCelsius = temp,
            isCharging = isCharging,
            threshold = threshold
        )

        evaluateDutyCyclePolicy(threshold)
    }

    /**
     * Rescuers can simulate various battery levels (e.g. 14% to trigger <20% Critical Red duty cycling,
     * 35% for Warning Amber, or 80% for Emerald Green) to verify mission survival behavior.
     */
    fun setSimulatedPercentage(simulatedPct: Int) {
        val clamped = simulatedPct.coerceIn(1, 100)
        val threshold = SurvivalThreshold.fromBatteryPercentage(clamped)
        _state.value = _state.value.copy(
            isSimulatedOverride = true,
            activePercentage = clamped,
            threshold = threshold
        )
        evaluateDutyCyclePolicy(threshold)
    }

    fun resetToHardwareBattery() {
        val realPct = _state.value.realHardwarePercentage
        val threshold = SurvivalThreshold.fromBatteryPercentage(realPct)
        _state.value = _state.value.copy(
            isSimulatedOverride = false,
            activePercentage = realPct,
            threshold = threshold
        )
        evaluateDutyCyclePolicy(threshold)
    }

    /**
     * Evaluates whether automated 15-minute deep-sleep duty cycling via AlarmManager should be armed:
     * - Triggered automatically when threshold is CRITICAL_RED (< 20%)
     * - Disarmed when battery is restored to WARNING_AMBER or EMERALD_GREEN (>= 20%)
     */
    private fun evaluateDutyCyclePolicy(threshold: SurvivalThreshold) {
        if (threshold == SurvivalThreshold.CRITICAL_RED) {
            if (!_state.value.isDutyCycleActive) {
                armAutomatedDutyCycling()
            }
        } else {
            if (_state.value.isDutyCycleActive) {
                disarmDutyCycling()
            }
        }
    }

    fun armAutomatedDutyCycling() {
        Log.i("BatteryMonitor", "Entering automated 15-min deep-sleep duty cycling (Battery < 20%)")
        _state.value = _state.value.copy(
            isDutyCycleActive = true,
            isDeepSleeping = true,
            isAwakeBurst = false,
            secondsRemainingInCurrentCycle = 15 * 60 // 15 minutes = 900 seconds
        )
        scheduleAlarmManagerWakeup(15 * 60 * 1000L)
    }

    fun disarmDutyCycling() {
        Log.i("BatteryMonitor", "Disarming duty cycling (Battery restored or manual disarm)")
        cancelAlarmManagerSchedule()
        _state.value = _state.value.copy(
            isDutyCycleActive = false,
            isDeepSleeping = false,
            isAwakeBurst = true,
            secondsRemainingInCurrentCycle = 0
        )
    }

    fun forceWakeBurstNow() {
        // Operator manual trigger to wake immediately for a 30s radio burst
        cancelAlarmManagerSchedule()
        _state.value = _state.value.copy(
            isDeepSleeping = false,
            isAwakeBurst = true,
            secondsRemainingInCurrentCycle = 30,
            lastWakeupTimestampMillis = System.currentTimeMillis()
        )
    }

    fun forceSleepNow() {
        _state.value = _state.value.copy(
            isDeepSleeping = true,
            isAwakeBurst = false,
            secondsRemainingInCurrentCycle = 15 * 60
        )
        scheduleAlarmManagerWakeup(15 * 60 * 1000L)
    }

    private fun scheduleAlarmManagerWakeup(delayMillis: Long) {
        if (alarmManager == null) return
        val intent = Intent(context, DutyCycleAlarmReceiver::class.java).apply {
            action = DutyCycleAlarmReceiver.ACTION_DUTY_CYCLE_WAKEUP
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            DutyCycleAlarmReceiver.REQUEST_CODE_DUTY_CYCLE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val triggerAtMillis = SystemClock.elapsedRealtime() + delayMillis

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.ELAPSED_REALTIME_WAKEUP,
                    triggerAtMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.ELAPSED_REALTIME_WAKEUP,
                    triggerAtMillis,
                    pendingIntent
                )
            }
            Log.d("BatteryMonitor", "Scheduled AlarmManager wakeup in ${delayMillis / 1000}s")
        } catch (e: SecurityException) {
            Log.w("BatteryMonitor", "Exact alarm permission not granted, falling back to setAndAllowWhileIdle", e)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setAndAllowWhileIdle(
                    AlarmManager.ELAPSED_REALTIME_WAKEUP,
                    triggerAtMillis,
                    pendingIntent
                )
            }
        }
    }

    private fun cancelAlarmManagerSchedule() {
        val intent = Intent(context, DutyCycleAlarmReceiver::class.java).apply {
            action = DutyCycleAlarmReceiver.ACTION_DUTY_CYCLE_WAKEUP
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            DutyCycleAlarmReceiver.REQUEST_CODE_DUTY_CYCLE,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager?.cancel(pendingIntent)
        }
    }

    private fun startCycleTicker() {
        countdownJob?.cancel()
        countdownJob = scope.launch(Dispatchers.Default) {
            while (isActive) {
                delay(1000)
                if (_state.value.isDutyCycleActive) {
                    val currentSec = _state.value.secondsRemainingInCurrentCycle
                    if (currentSec > 1) {
                        _state.value = _state.value.copy(secondsRemainingInCurrentCycle = currentSec - 1)
                    } else {
                        // Switch phases:
                        if (_state.value.isDeepSleeping) {
                            // 15-minute sleep ended, transition to 30-second awake burst
                            _state.value = _state.value.copy(
                                isDeepSleeping = false,
                                isAwakeBurst = true,
                                secondsRemainingInCurrentCycle = 30,
                                totalCyclesCompleted = _state.value.totalCyclesCompleted + 1,
                                lastWakeupTimestampMillis = System.currentTimeMillis()
                            )
                        } else {
                            // 30-second awake burst ended, transition back to 15-minute sleep
                            _state.value = _state.value.copy(
                                isDeepSleeping = true,
                                isAwakeBurst = false,
                                secondsRemainingInCurrentCycle = 15 * 60
                            )
                            scheduleAlarmManagerWakeup(15 * 60 * 1000L)
                        }
                    }
                }
            }
        }
    }

    companion object {
        private var instance: HardwareBatteryMonitor? = null

        fun onDutyCycleAlarmFired() {
            instance?.let { monitor ->
                monitor.forceWakeBurstNow()
            }
        }
    }
}
