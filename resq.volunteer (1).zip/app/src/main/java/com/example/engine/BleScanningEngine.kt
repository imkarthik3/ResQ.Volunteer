package com.example.engine

import android.content.Context
import com.example.data.BeaconEntity
import com.example.data.TriageRepository
import com.example.model.BeaconPacket
import com.example.model.TraumaFlags
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.random.Random

data class ActiveForwardingBroadcast(
    val packetHash: String,
    val survivorId: String,
    val ttlRemaining: Int,
    val hopCount: Int,
    val secondsRemaining: Int,
    val totalSeconds: Int = 15
)

data class BleScanEngineState(
    val isScanning: Boolean = true,
    val isAdvertisingMesh: Boolean = false,
    val totalPacketsCaptured: Int = 0,
    val deduplicatedDuplicates: Int = 0,
    val activeMultiHopBroadcasts: List<ActiveForwardingBroadcast> = emptyList(),
    val lastInterceptedTimeMillis: Long = System.currentTimeMillis()
)

class BleScanningEngine(
    private val repository: TriageRepository,
    private val scope: CoroutineScope
) {
    private val _state = MutableStateFlow(BleScanEngineState())
    val state: StateFlow<BleScanEngineState> = _state.asStateFlow()

    private var scanJob: Job? = null
    private var forwardingCountdownJob: Job? = null
    private val activeBroadcasts = mutableListOf<ActiveForwardingBroadcast>()

    init {
        startContinuousScanning()
        startForwardingTimerLoop()
    }

    fun startContinuousScanning() {
        if (scanJob?.isActive == true) return
        _state.value = _state.value.copy(isScanning = true)
        
        scanJob = scope.launch(Dispatchers.Default) {
            // Autonomous background BLE scanning engine loop
            while (isActive) {
                // Background scan pulse every 12-25 seconds (simulating opportunistic radio burst captures)
                val delayTime = Random.nextLong(12000, 25000)
                delay(delayTime)
                
                if (_state.value.isScanning) {
                    // Occasionally capture a multi-hop relayed burst or fresh survivor beacon
                    simulateOpportunisticBurst()
                }
            }
        }
    }

    fun stopScanning() {
        scanJob?.cancel()
        _state.value = _state.value.copy(isScanning = false)
    }

    fun toggleScanning() {
        if (_state.value.isScanning) {
            stopScanning()
        } else {
            startContinuousScanning()
        }
    }

    /**
     * Intercepts a raw or simulated 30-byte BLE emergency packet (0xFFFF)
     */
    fun onRawPacketReceived(rawBytes: ByteArray, rssi: Int = -74, relayNode: String = "Direct") {
        scope.launch(Dispatchers.IO) {
            val packet = BeaconPacket.decode(rawBytes, rssi, relayNode) ?: return@launch
            handleDecodedPacket(packet)
        }
    }

    /**
     * Handles parsed packet:
     * - Checks SHA-256 deduplication against Room SQLite database
     * - If NEW and TTL > 1: decrements TTL, increments hop count, and re-broadcasts for 15 seconds
     */
    suspend fun handleDecodedPacket(packet: BeaconPacket) {
        val isNew = repository.interceptPacket(packet, determineSector(packet.latitude, packet.longitude))
        
        if (isNew) {
            _state.value = _state.value.copy(
                totalPacketsCaptured = _state.value.totalPacketsCaptured + 1,
                lastInterceptedTimeMillis = System.currentTimeMillis()
            )

            // Autonomous multi-hop forwarding engine
            if (packet.ttl > 1) {
                val forwardHop = packet.forwardMultiHop("Console-Relay-${Random.nextInt(10, 99)}")
                if (forwardHop != null) {
                    startMultiHopRebroadcast(forwardHop)
                }
            }
        } else {
            _state.value = _state.value.copy(
                deduplicatedDuplicates = _state.value.deduplicatedDuplicates + 1
            )
        }
    }

    private fun startMultiHopRebroadcast(packet: BeaconPacket) {
        val broadcast = ActiveForwardingBroadcast(
            packetHash = packet.sha256Hash,
            survivorId = packet.survivorId,
            ttlRemaining = packet.ttl,
            hopCount = packet.hopCount,
            secondsRemaining = 15,
            totalSeconds = 15
        )
        synchronized(activeBroadcasts) {
            activeBroadcasts.removeAll { it.packetHash == packet.sha256Hash }
            activeBroadcasts.add(broadcast)
        }
        _state.value = _state.value.copy(
            isAdvertisingMesh = true,
            activeMultiHopBroadcasts = activeBroadcasts.toList()
        )
    }

    private fun startForwardingTimerLoop() {
        forwardingCountdownJob = scope.launch(Dispatchers.Default) {
            while (isActive) {
                delay(1000)
                synchronized(activeBroadcasts) {
                    if (activeBroadcasts.isNotEmpty()) {
                        val updated = mutableListOf<ActiveForwardingBroadcast>()
                        for (item in activeBroadcasts) {
                            val nextSec = item.secondsRemaining - 1
                            if (nextSec > 0) {
                                updated.add(item.copy(secondsRemaining = nextSec))
                            } else {
                                // 15s window expired for this packet re-broadcast
                                scope.launch(Dispatchers.IO) {
                                    repository.markAsForwarded(item.packetHash)
                                }
                            }
                        }
                        activeBroadcasts.clear()
                        activeBroadcasts.addAll(updated)
                        _state.value = _state.value.copy(
                            isAdvertisingMesh = activeBroadcasts.isNotEmpty(),
                            activeMultiHopBroadcasts = activeBroadcasts.toList()
                        )
                    }
                }
            }
        }
    }

    /**
     * Responders can inject a custom or synthetic emergency beacon to test mesh re-broadcasting,
     * QoS preemption, or Rubble Radar tracking!
     */
    fun injectSimulatedBeacon(
        survivorCount: Int,
        isTrapped: Boolean,
        hasSevereBleed: Boolean,
        isInsulinLow: Boolean,
        isOxygenLow: Boolean,
        isStrandedSupply: Boolean,
        ttl: Int = 4,
        hopCount: Int = 0,
        sectorName: String = "Sector Alpha (Collapsed Plaza)"
    ) {
        scope.launch(Dispatchers.IO) {
            val randomId = "VIC-" + Random.nextInt(1000, 9999)
            val flags = TraumaFlags(
                isTrappedUnderRubble = isTrapped,
                hasSevereHemorrhage = hasSevereBleed,
                isClusterThreePlus = survivorCount >= 3,
                isInsulinDepleted = isInsulinLow,
                isOxygenDepleted = isOxygenLow,
                isStrandedSupply = isStrandedSupply,
                requiresCanineSearch = isTrapped
            )
            // Sector offsets around central disaster coordinates (28.6139, 77.2090)
            val latOffset = Random.nextDouble(-0.0035, 0.0035)
            val lonOffset = Random.nextDouble(-0.0035, 0.0035)

            val packet = BeaconPacket(
                survivorId = randomId,
                survivorCount = survivorCount,
                flags = flags,
                latitude = 28.6139 + latOffset,
                longitude = 77.2090 + lonOffset,
                altitudeMeters = if (isTrapped) Random.nextFloat() * -5f - 1f else Random.nextFloat() * 2f,
                ttl = ttl,
                hopCount = hopCount,
                timestampSeconds = System.currentTimeMillis() / 1000,
                batteryPercent = Random.nextInt(15, 85),
                relayNodeName = if (hopCount > 0) "Relayed: Mesh-Node-${Random.nextInt(1, 5)}" else "Direct",
                rssi = Random.nextInt(-88, -52)
            )

            val rawBytes = BeaconPacket.encode(packet)
            val signedPacket = packet.copy(
                sha256Hash = BeaconPacket.computeSha256(rawBytes),
                rawPayloadHex = rawBytes.joinToString("") { "%02X".format(it) }
            )
            handleDecodedPacket(signedPacket)
        }
    }

    private suspend fun simulateOpportunisticBurst() {
        val scenarios = listOf(
            Triple("VIC-5519", true, "Relayed: NDRF-UAV-1"),
            Triple("VIC-2248", false, "Direct"),
            Triple("VIC-7731", true, "Relayed: SDRF-Canine-K9")
        )
        val scenario = scenarios.random()
        val flags = TraumaFlags(
            isTrappedUnderRubble = Random.nextBoolean(),
            hasSevereHemorrhage = Random.nextBoolean(),
            isInsulinDepleted = Random.nextBoolean(),
            isOxygenDepleted = Random.nextBoolean()
        )
        val packet = BeaconPacket(
            survivorId = scenario.first,
            survivorCount = Random.nextInt(1, 4),
            flags = flags,
            latitude = 28.6139 + Random.nextDouble(-0.003, 0.003),
            longitude = 77.2090 + Random.nextDouble(-0.003, 0.003),
            altitudeMeters = -2.5f,
            ttl = Random.nextInt(2, 5),
            hopCount = if (scenario.second) 1 else 0,
            timestampSeconds = System.currentTimeMillis() / 1000,
            batteryPercent = Random.nextInt(20, 90),
            relayNodeName = scenario.third,
            rssi = Random.nextInt(-85, -60)
        )
        val raw = BeaconPacket.encode(packet)
        val signed = packet.copy(
            sha256Hash = BeaconPacket.computeSha256(raw),
            rawPayloadHex = raw.joinToString("") { "%02X".format(it) }
        )
        handleDecodedPacket(signed)
    }

    private fun determineSector(lat: Double, lon: Double): String {
        return when {
            lat >= 28.6145 && lon >= 77.2100 -> "Sector Bravo (Riverbank Void)"
            lat >= 28.6145 && lon < 77.2100 -> "Sector Delta (Residential)"
            lat < 28.6145 && lon < 77.2090 -> "Sector Charlie (Metro Tunnel)"
            else -> "Sector Alpha (Plaza Collapse)"
        }
    }
}
