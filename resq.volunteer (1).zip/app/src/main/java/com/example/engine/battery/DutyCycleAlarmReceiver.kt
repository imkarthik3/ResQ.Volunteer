package com.example.engine.battery

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class DutyCycleAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        if (intent?.action == ACTION_DUTY_CYCLE_WAKEUP) {
            Log.d("DutyCycleAlarm", "AlarmManager 15-minute wake-up triggered for rapid triage burst")
            HardwareBatteryMonitor.onDutyCycleAlarmFired()
        }
    }

    companion object {
        const val ACTION_DUTY_CYCLE_WAKEUP = "com.aistudio.triageconsole.ACTION_DUTY_CYCLE_WAKEUP"
        const val REQUEST_CODE_DUTY_CYCLE = 991
    }
}
