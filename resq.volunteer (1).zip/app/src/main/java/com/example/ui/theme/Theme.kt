package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TacticalColorScheme = darkColorScheme(
  primary = TacticalCyan,
  onPrimary = Color(0xFF00363D),
  primaryContainer = Color(0xFF004F58),
  onPrimaryContainer = Color(0xFF97F0FF),
  secondary = UrgentAmber,
  onSecondary = Color(0xFF452B00),
  secondaryContainer = Color(0xFF633F00),
  onSecondaryContainer = Color(0xFFFFDCC0),
  tertiary = UrgentCrimson,
  onTertiary = Color(0xFFFFFFFF),
  tertiaryContainer = Color(0xFF930018),
  onTertiaryContainer = Color(0xFFFFDAD8),
  background = TacticalDarkBg,
  onBackground = TextPrimary,
  surface = TacticalSurface,
  onSurface = TextPrimary,
  surfaceVariant = TacticalSurfaceVariant,
  onSurfaceVariant = TextSecondary,
  outline = TacticalBorder,
  error = UrgentCrimson,
  onError = Color.White
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  dynamicColor: Boolean = false, // Always enforce high-visibility tactical theme for disaster zones
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = TacticalColorScheme,
    typography = Typography,
    content = content
  )
}

