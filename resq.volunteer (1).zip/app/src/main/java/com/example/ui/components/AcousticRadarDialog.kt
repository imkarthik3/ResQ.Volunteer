package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.engine.audio.AcousticRadarState
import com.example.ui.theme.*

@Composable
fun AcousticRadarDialog(
    acousticState: AcousticRadarState,
    onDismiss: () -> Unit,
    onToggleEnabled: () -> Unit,
    onSetVolume: (Float) -> Unit,
    onToggleMute: () -> Unit,
    onTriggerTestPip: () -> Unit,
    onUpdateRssi: (Int) -> Unit
) {
    val pipColor by animateColorAsState(
        targetValue = if (acousticState.isPipFlashing) Color(0xFF00E5FF) else Color(0xFF1E3A5F),
        label = "pipFlash"
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("acoustic_radar_dialog"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = TacticalCardBg),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, CyanAccent)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth()
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(if (acousticState.isEnabled) Color(0x3300E5FF) else Color(0x22FFFFFF)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Hearing,
                                contentDescription = "Acoustic Radar",
                                tint = if (acousticState.isEnabled) CyanAccent else TextSecondary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "ACOUSTIC PROXIMITY RADAR",
                                color = TextPrimary,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "Real-Time 16-bit PCM AudioTrack Geiger Engine",
                                color = TextSecondary,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Master Toggle Banner
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (acousticState.isEnabled) Color(0x1F00E5FF) else TacticalDarkBg
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (acousticState.isEnabled) CyanAccent else BorderStroke
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (acousticState.isEnabled) "ACOUSTIC RADAR: ACTIVE" else "ACOUSTIC RADAR: MUTED / OFF",
                                color = if (acousticState.isEnabled) CyanAccent else TextSecondary,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "Hands-free navigation through smoke & rubble",
                                color = TextSecondary,
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 11.sp
                            )
                        }
                        Switch(
                            checked = acousticState.isEnabled,
                            onCheckedChange = { onToggleEnabled() },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.Black,
                                checkedTrackColor = CyanAccent
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Geiger Visual Pip and Frequency Gauges
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Pulsing Pip indicator
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(CircleShape)
                            .background(pipColor)
                            .border(2.dp, if (acousticState.isPipFlashing) Color.White else CyanAccent, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = "Pip",
                            tint = if (acousticState.isPipFlashing) Color.White else CyanAccent,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("SYNTH FREQUENCY", color = TextSecondary, style = MaterialTheme.typography.labelSmall)
                            Text(
                                "${acousticState.currentFrequencyHz} Hz",
                                color = CyanAccent,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("PULSE CADENCE", color = TextSecondary, style = MaterialTheme.typography.labelSmall)
                            Text(
                                "${acousticState.currentIntervalMs} ms (${acousticState.beepsPerMinute} BPM)",
                                color = TextPrimary,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("INPUT RSSI", color = TextSecondary, style = MaterialTheme.typography.labelSmall)
                            Text(
                                "${acousticState.currentRssiDbm} dBm",
                                color = YellowAlert,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Scaling Law explanation bar
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = TacticalDarkBg),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderStroke)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "CONTINUOUS GEIGER SCALING LAW:",
                            color = TextSecondary,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "• -85 dBm: Slow 800 Hz pips every 1.8 seconds (distant/deep void)\n• -50 dBm: Rapid 2400 Hz alerts every 100 ms (surface extraction)",
                            color = TextPrimary,
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Manual RSSI Sweep Slider (Simulation & Testing)
                Text(
                    text = "MANUAL RSSI PROXIMITY SWEEP: ${acousticState.currentRssiDbm} dBm",
                    color = TextSecondary,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold
                )
                Slider(
                    value = acousticState.currentRssiDbm.toFloat(),
                    onValueChange = { onUpdateRssi(it.toInt()) },
                    valueRange = -85f..-50f,
                    colors = SliderDefaults.colors(
                        thumbColor = CyanAccent,
                        activeTrackColor = CyanAccent,
                        inactiveTrackColor = BorderStroke
                    )
                )

                // Volume Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onToggleMute) {
                            Icon(
                                imageVector = if (acousticState.isMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                                contentDescription = "Mute",
                                tint = if (acousticState.isMuted) RedCritical else CyanAccent
                            )
                        }
                        Text(
                            text = if (acousticState.isMuted) "MUTED" else "VOL ${(acousticState.volume * 100).toInt()}%",
                            color = TextPrimary,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Button(
                        onClick = onTriggerTestPip,
                        colors = ButtonDefaults.buttonColors(containerColor = CyanAccent),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Test Tone", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
