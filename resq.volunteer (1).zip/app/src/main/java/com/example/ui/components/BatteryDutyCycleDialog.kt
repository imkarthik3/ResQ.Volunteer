package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.engine.battery.BatteryMonitorState
import com.example.engine.battery.SurvivalThreshold
import com.example.ui.theme.*

@Composable
fun BatteryDutyCycleDialog(
    batteryState: BatteryMonitorState,
    onDismiss: () -> Unit,
    onSetSimulatedPct: (Int) -> Unit,
    onResetHardware: () -> Unit,
    onForceWakeBurst: () -> Unit,
    onForceSleep: () -> Unit,
    onArmDutyCycle: () -> Unit,
    onDisarmDutyCycle: () -> Unit
) {
    val threshold = batteryState.threshold
    val thresholdColor by animateColorAsState(targetValue = threshold.primaryColor, label = "thresholdColor")

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("battery_duty_cycle_dialog"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = TacticalCardBg),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, thresholdColor)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth()
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(threshold.containerColor),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (batteryState.isCharging) Icons.Default.BatteryChargingFull else Icons.Default.BatteryStd,
                                contentDescription = "Battery",
                                tint = thresholdColor,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "HARDWARE BATTERY & POWER",
                                color = TextPrimary,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "Off-Grid Disaster Survival Duty Cycling",
                                color = TextSecondary,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Threshold Banner
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = threshold.containerColor),
                    border = androidx.compose.foundation.BorderStroke(1.dp, threshold.borderColor)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = threshold.label,
                                color = threshold.primaryColor,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                text = threshold.rangeDescription,
                                color = TextSecondary,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Text(
                            text = "${batteryState.activePercentage}%",
                            color = threshold.primaryColor,
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Real Hardware Stats
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MetricMiniCard(
                        title = "VOLTAGE",
                        value = "${batteryState.voltageMv} mV",
                        modifier = Modifier.weight(1f)
                    )
                    MetricMiniCard(
                        title = "TEMPERATURE",
                        value = "${batteryState.temperatureCelsius}°C",
                        modifier = Modifier.weight(1f)
                    )
                    MetricMiniCard(
                        title = "CHARGING",
                        value = if (batteryState.isCharging) "YES" else "DISCHARGING",
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // AlarmManager 15-Minute Deep-Sleep Section
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = TacticalDarkBg),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (batteryState.isDutyCycleActive) Color(0xFFFF1744) else BorderStroke
                    )
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Bedtime,
                                    contentDescription = "Duty Cycle",
                                    tint = if (batteryState.isDutyCycleActive) Color(0xFFFF1744) else TextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "15-MIN DEEP-SLEEP DUTY CYCLING",
                                    color = TextPrimary,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = if (batteryState.isDutyCycleActive) "ACTIVE" else "DISARMED",
                                color = if (batteryState.isDutyCycleActive) Color(0xFFFF1744) else TextSecondary,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Black
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        if (batteryState.isDutyCycleActive) {
                            val phase = if (batteryState.isDeepSleeping) "DEEP SLEEP (15 MIN)" else "AWAKE BURST (30 SEC)"
                            val phaseColor = if (batteryState.isDeepSleeping) Color(0xFFFFB300) else Color(0xFF00E676)
                            val minutes = batteryState.secondsRemainingInCurrentCycle / 60
                            val seconds = batteryState.secondsRemainingInCurrentCycle % 60

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "CURRENT PHASE: $phase",
                                    color = phaseColor,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "%02d:%02d".format(minutes, seconds),
                                    color = TextPrimary,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Black,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Text(
                                text = "Next AlarmManager wake-up scheduled via ELAPSED_REALTIME_WAKEUP. Completed: ${batteryState.totalCyclesCompleted} cycles.",
                                color = TextSecondary,
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 11.sp
                            )
                        } else {
                            Text(
                                text = "Automatically triggers when battery drops below 20% (< 20% Critical Red) to preserve remaining phone power for victim radio discovery.",
                                color = TextSecondary,
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 11.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Controls
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = onForceWakeBurst,
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                            ) {
                                Text("Wake 30s", fontSize = 11.sp)
                            }
                            OutlinedButton(
                                onClick = onForceSleep,
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                            ) {
                                Text("Sleep 15m", fontSize = 11.sp)
                            }
                            Button(
                                onClick = {
                                    if (batteryState.isDutyCycleActive) onDisarmDutyCycle() else onArmDutyCycle()
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (batteryState.isDutyCycleActive) Color(0xFFFF1744) else CyanAccent
                                ),
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                            ) {
                                Text(if (batteryState.isDutyCycleActive) "Disarm" else "Arm", fontSize = 11.sp, color = Color.Black)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Threshold Simulation Panel
                Text(
                    text = "SURVIVAL THRESHOLD SIMULATOR",
                    color = TextSecondary,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Button(
                        onClick = { onSetSimulatedPct(82) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676)),
                        contentPadding = PaddingValues(4.dp)
                    ) {
                        Text("≥50% Green", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { onSetSimulatedPct(38) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB300)),
                        contentPadding = PaddingValues(4.dp)
                    ) {
                        Text("20-49% Amber", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { onSetSimulatedPct(14) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF1744)),
                        contentPadding = PaddingValues(4.dp)
                    ) {
                        Text("<20% Red", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                if (batteryState.isSimulatedOverride) {
                    OutlinedButton(
                        onClick = onResetHardware,
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Reset to Real Device Battery (${batteryState.realHardwarePercentage}%)", fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricMiniCard(
    title: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = TacticalDarkBg),
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderStroke)
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                color = TextSecondary,
                style = MaterialTheme.typography.labelSmall,
                fontSize = 9.sp
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                color = TextPrimary,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
