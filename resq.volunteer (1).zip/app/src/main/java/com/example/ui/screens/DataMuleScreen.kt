package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DataMuleSyncEntity
import com.example.engine.PeerResponderNode
import com.example.ui.TriageViewModel
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun DataMuleScreen(
    viewModel: TriageViewModel,
    modifier: Modifier = Modifier
) {
    val muleState by viewModel.dataMuleState.collectAsState()
    val syncLogs by viewModel.syncLogs.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TacticalDarkBg)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Data Mule Architecture Summary Card
        item {
            DataMuleSummaryHeader(
                totalMerged = muleState.totalDifferentialRecordsMerged,
                totalExchanges = muleState.totalHashExchanges,
                lastSummary = muleState.lastSyncSummary,
                isSyncing = muleState.isSyncingInProgress
            )
        }

        // 2. Section Header: Discovered Responder Peers (P2P_CLUSTER)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "DISCOVERED RESPONDER CONSOLES (Wi-Fi Direct)",
                    style = MaterialTheme.typography.labelMedium,
                    color = TacticalCyan,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "${muleState.activePeers.size} PEERS",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
            }
        }

        // 3. List of Active Peer Nodes
        items(muleState.activePeers, key = { it.peerId }) { peer ->
            PeerResponderCard(
                peer = peer,
                onTriggerSync = { viewModel.dataMuleEngine.triggerDifferentialSyncWithPeer(peer.peerId) }
            )
        }

        // 4. Differential Sync Audit History
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "DIFFERENTIAL DATABASE MERGE AUDIT TRAIL",
                style = MaterialTheme.typography.labelMedium,
                color = TacticalCyan,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        }

        if (syncLogs.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = TacticalSurface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(16.dp), contentAlignment = Alignment.Center) {
                        Text("No peer sync transactions logged yet.", color = TextMuted, fontSize = 12.sp)
                    }
                }
            }
        } else {
            items(syncLogs, key = { it.id }) { log ->
                SyncLogCard(log = log)
            }
        }
    }
}

@Composable
fun DataMuleSummaryHeader(
    totalMerged: Int,
    totalExchanges: Int,
    lastSummary: String,
    isSyncing: Boolean
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = TacticalSurface),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("data_mule_summary_header")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Share, contentDescription = "P2P", tint = TacticalCyan, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "DELAY-TOLERANT DATA MULE (P2P_CLUSTER)",
                        color = TacticalCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                if (isSyncing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp,
                        color = TacticalCyan
                    )
                } else {
                    Text(
                        text = "DISCOVERY IDLE",
                        color = SafeGreen,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Bridges severed mountain roads, flooded rivers, and collapsed sectors via autonomous peer-to-peer differential database merges between rescue vehicles, boats, and canine units.",
                color = TextSecondary,
                fontSize = 11.sp
            )

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = TacticalBorder)
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("DIFFERENTIAL RECORDS MERGED", color = TextSecondary, fontSize = 10.sp)
                    Text("$totalMerged Records", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("HASH EXCHANGES", color = TextSecondary, fontSize = 10.sp)
                    Text("$totalExchanges Completed", color = TacticalCyan, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(TacticalSurfaceElevated)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "Status: $lastSummary",
                    color = SafeGreen,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun PeerResponderCard(
    peer: PeerResponderNode,
    onTriggerSync: () -> Unit
) {
    val typeIcon = when (peer.type) {
        "CANINE_TEAM" -> Icons.Default.Pets
        "RESCUE_BOAT" -> Icons.Default.DirectionsBoat
        "VEHICLE" -> Icons.Default.AirportShuttle
        "COMMAND_HQ" -> Icons.Default.Security
        else -> Icons.Default.Hub
    }

    val stateColor = when (peer.syncState) {
        "SYNCHRONIZED" -> SafeGreen
        "HANDSHAKE", "MERGING" -> UrgentAmber
        else -> TextSecondary
    }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = TacticalSurface),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("peer_card_${peer.peerId}")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(TacticalSurfaceElevated),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = typeIcon, contentDescription = peer.type, tint = TacticalCyan, modifier = Modifier.size(20.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(peer.name, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("${peer.sector} • ${peer.distanceMeters}m away", color = TextSecondary, fontSize = 11.sp)
                    }
                }

                // Sync Status Pill
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(stateColor.copy(alpha = 0.15f))
                        .border(1.dp, stateColor.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(peer.syncState, color = stateColor, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Wi-Fi Signal: ${peer.signalDbm} dBm • Synced: ${peer.totalSynchronizedPackets} records",
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )

                OutlinedButton(
                    onClick = onTriggerSync,
                    modifier = Modifier
                        .height(32.dp)
                        .testTag("btn_sync_${peer.peerId}"),
                    contentPadding = PaddingValues(horizontal = 8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Sync, contentDescription = "Sync", modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("TRIGGER MERGE", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun SyncLogCard(log: DataMuleSyncEntity) {
    val dateStr = remember(log.timestampMillis) {
        val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        sdf.format(Date(log.timestampMillis))
    }

    Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = TacticalSurfaceElevated),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Differential Merge with ${log.peerName}",
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "$dateStr • ${log.packetsExchanged} packet hashes verified",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(SafeGreenBg)
                    .padding(horizontal = 6.dp, vertical = 3.dp)
            ) {
                Text(
                    text = "+${log.missingMerged} New",
                    color = SafeGreen,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
