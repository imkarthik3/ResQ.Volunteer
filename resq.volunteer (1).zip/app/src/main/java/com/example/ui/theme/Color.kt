package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Tactical Disaster Response Palette
val TacticalDarkBg = Color(0xFF080E14)
val TacticalSurface = Color(0xFF0F1B26)
val TacticalSurfaceVariant = Color(0xFF162534)
val TacticalSurfaceElevated = Color(0xFF1C3144)
val TacticalBorder = Color(0xFF263E54)

val TacticalCyan = Color(0xFF00E5FF)
val TacticalCyanGlow = Color(0x3300E5FF)

val UrgentCrimson = Color(0xFFFF1744) // Level 1 (Structural entrapment, severe hemorrhage, 3+ cluster)
val UrgentCrimsonBg = Color(0x29FF1744)

val UrgentAmber = Color(0xFFFF9100) // Level 2 (Medical resource shortage, insulin/oxygen)
val UrgentAmberBg = Color(0x29FF9100)

val SafeGreen = Color(0xFF00E676) // Level 3 (Non-critical, supply check-in)
val SafeGreenBg = Color(0x2900E676)

val TextPrimary = Color(0xFFF0F6FC)
val TextSecondary = Color(0xFF90A4AE)
val TextMuted = Color(0xFF546E7A)
val RadarGreen = Color(0xFF39FF14)

val TacticalCardBg = TacticalSurface
val CyanAccent = TacticalCyan
val BorderStroke = TacticalBorder
val YellowAlert = UrgentAmber
val RedCritical = UrgentCrimson

