package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BeaconEntity
import com.example.engine.PhysicalDebrisZone
import com.example.ui.TriageViewModel
import com.example.ui.theme.*
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun RubbleRadarScreen(
    viewModel: TriageViewModel,
    modifier: Modifier = Modifier
) {
    val radarState by viewModel.radarState.collectAsState()
    val acousticState by viewModel.acousticState.collectAsState()
    val allBeacons by viewModel.rankedBeacons.collectAsState()
    val targetSurvivor = radarState.targetSurvivor

    // Continuous rotating radar sweep angle animation
    val infiniteTransition = rememberInfiniteTransition(label = "radar_sweep")
    val sweepAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "sweep_angle"
    )

    // Pulse animation for surface extraction zone
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_strobe"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TacticalDarkBg)
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // 1. Target Survivor Selector Header
        TargetSurvivorSelectorBanner(
            selectedTarget = targetSurvivor,
            allBeacons = allBeacons,
            onSelect = { viewModel.rubbleRadarEngine.selectTargetSurvivor(it) }
        )

        Spacer(modifier = Modifier.height(12.dp))

        if (targetSurvivor == null) {
            EmptyTargetPlaceholder(
                allBeacons = allBeacons,
                onSelectFirst = { if (allBeacons.isNotEmpty()) viewModel.rubbleRadarEngine.selectTargetSurvivor(allBeacons.first()) }
            )
        } else {
            // 2. High-Tech Sonar / Rubble Radar Canvas
            RadarSonarCanvas(
                sweepAngle = sweepAngle,
                filteredEmaDbm = radarState.filteredEmaDbm,
                currentZone = radarState.currentZone,
                isBuzzerActive = radarState.isBuzzerStrobeActive,
                pulseAlpha = pulseAlpha
            )

            Spacer(modifier = Modifier.height(14.dp))

            // 3. Physical Debris Zone Indicator Card
            PhysicalZoneTelemetryCard(
                currentZone = radarState.currentZone,
                filteredEmaDbm = radarState.filteredEmaDbm,
                rawRssiDbm = radarState.rawRssiDbm,
                estimatedMeters = radarState.estimatedMeters,
                alpha = radarState.multipathJitterFilterAlpha,
                onAlphaChange = { viewModel.rubbleRadarEngine.setFilterAlpha(it) },
                pulseAlpha = pulseAlpha
            )

            Spacer(modifier = Modifier.height(12.dp))

            // 3.5. Hands-Free Acoustic Geiger Radar Proximity Card (16-bit PCM AudioTrack)
            AcousticGeigerRadarCard(
                acousticState = acousticState,
                onToggleEnabled = { viewModel.acousticRadarAudioEngine.toggleEnabled() },
                onSetVolume = { viewModel.acousticRadarAudioEngine.setVolume(it) },
                onToggleMute = { viewModel.acousticRadarAudioEngine.toggleMute() },
                onTriggerPip = { viewModel.acousticRadarAudioEngine.triggerSingleTestBeep() }
            )

            Spacer(modifier = Modifier.height(12.dp))

            // 4. Real-time 2.4 GHz Multipath Signal Jitter Wave Display
            SignalHistoryWaveform(history = radarState.rssiHistory)

            Spacer(modifier = Modifier.height(14.dp))

            // 5. Authenticated 0xFFEE Acoustic Buzzer + LED Strobe Command Button
            AcousticOpticalTriggerCard(
                isBuzzerActive = radarState.isBuzzerStrobeActive,
                secondsRemaining = radarState.buzzerSecondsRemaining,
                commandHex = radarState.lastCommandTransmittedHex,
                pulseAlpha = pulseAlpha,
                onTransmit = { viewModel.rubbleRadarEngine.transmitAcousticOpticalTrigger() }
            )
        }
    }
}

@Composable
fun TargetSurvivorSelectorBanner(
    selectedTarget: BeaconEntity?,
    allBeacons: List<BeaconEntity>,
    onSelect: (BeaconEntity) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = TacticalSurface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Radar, contentDescription = "Radar", tint = UrgentCrimson, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "RUBBLE RADAR MICRO-LOCALIZATION",
                        color = TacticalCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                Box {
                    FilledTonalButton(
                        onClick = { expanded = true },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(30.dp)
                            .testTag("btn_select_target_survivor")
                    ) {
                        Text("TARGET: ${selectedTarget?.survivorId ?: "SELECT"}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = "Dropdown", modifier = Modifier.size(16.dp))
                    }

                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        allBeacons.forEach { b ->
                            DropdownMenuItem(
                                text = {
                                    Text("${b.survivorId} (${b.survivorCount}p) - ${b.sector}", fontSize = 12.sp)
                                },
                                onClick = {
                                    onSelect(b)
                                    expanded = false
                                }
                            )
                        }
                    }
                }
            }

            if (selectedTarget != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Locked on 2.4 GHz Burst from ${selectedTarget.survivorId} (${selectedTarget.survivorCount} survivors)",
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "• ${selectedTarget.sector}",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
fun EmptyTargetPlaceholder(allBeacons: List<BeaconEntity>, onSelectFirst: () -> Unit) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = TacticalSurface),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 24.dp)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(imageVector = Icons.Default.SensorsOff, contentDescription = "No Target", tint = TextSecondary, modifier = Modifier.size(56.dp))
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "NO SURVIVOR TARGET SELECTED",
                color = TextPrimary,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Select a trapped victim beacon from the Incident Command Triage Dashboard or tap below to track highest-priority Level 1 beacon.",
                color = TextSecondary,
                fontSize = 12.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                modifier = Modifier.padding(vertical = 8.dp)
            )
            Button(
                onClick = onSelectFirst,
                colors = ButtonDefaults.buttonColors(containerColor = UrgentCrimson),
                modifier = Modifier.testTag("btn_lock_highest_priority")
            ) {
                Icon(imageVector = Icons.Default.Lock, contentDescription = "Lock", tint = Color.White)
                Spacer(modifier = Modifier.width(6.dp))
                Text("LOCK ONTO CRITICAL LEVEL 1 BEACON", fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}

@Composable
fun RadarSonarCanvas(
    sweepAngle: Float,
    filteredEmaDbm: Float,
    currentZone: PhysicalDebrisZone,
    isBuzzerActive: Boolean,
    pulseAlpha: Float
) {
    Box(
        modifier = Modifier
            .size(280.dp)
            .clip(CircleShape)
            .background(Color(0xFF07121C))
            .border(2.dp, TacticalBorder, CircleShape)
            .testTag("radar_sonar_canvas"),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val c = center
            val maxR = size.minDimension / 2f

            // Draw concentric physical distance zones:
            // Zone 1: Surface Extraction Perimeter (< 2m) -> Inner circle (30% radius)
            // Zone 2: Approaching Void (3 to 8m) -> Mid circle (65% radius)
            // Zone 3: Deep Cavity (10 to 15m) -> Outer circle (95% radius)

            // Outer Zone 3 Circle (-90 to -80 dBm: 10-15m)
            drawCircle(
                color = Color(0x33FF9100),
                radius = maxR * 0.95f,
                center = c,
                style = Stroke(width = 1.5f)
            )

            // Mid Zone 2 Circle (-79 to -65 dBm: 3-8m)
            drawCircle(
                color = Color(0x55FF5722),
                radius = maxR * 0.65f,
                center = c,
                style = Stroke(width = 2f)
            )

            // Inner Zone 1 Circle (-64 to -45 dBm: < 2m surface extraction)
            val zone1Color = if (currentZone == PhysicalDebrisZone.ZONE_SURFACE_EXTRACTION) {
                UrgentCrimson.copy(alpha = pulseAlpha)
            } else {
                Color(0x33FF1744)
            }
            drawCircle(
                color = zone1Color,
                radius = maxR * 0.32f,
                center = c,
                style = Stroke(width = 2.5f)
            )

            // Crosshair Axes
            drawLine(color = Color(0x2200E5FF), start = Offset(c.x, 0f), end = Offset(c.x, size.height), strokeWidth = 1f)
            drawLine(color = Color(0x2200E5FF), start = Offset(0f, c.y), end = Offset(size.width, c.y), strokeWidth = 1f)

            // Rotating Radar Sweep Beam Line & Gradient Arc
            rotate(degrees = sweepAngle, pivot = c) {
                val sweepRad = Math.toRadians(sweepAngle.toDouble())
                val endPoint = Offset(
                    c.x + maxR * cos(sweepRad).toFloat(),
                    c.y + maxR * sin(sweepRad).toFloat()
                )
                drawLine(
                    color = TacticalCyan,
                    start = c,
                    end = endPoint,
                    strokeWidth = 2.5f
                )
            }

            // Target Blip Position calculated from Filtered EMA dBm (-95 to -45 dBm)
            val normalizedRatio = ((filteredEmaDbm - (-95f)) / 50f).coerceIn(0.1f, 0.95f)
            // Stronger signal = closer to center (1 - ratio)
            val targetDistanceRadius = maxR * (1f - normalizedRatio * 0.85f)

            // Target Blip at 45 degree angle
            val blipAngleRad = Math.toRadians(45.0)
            val blipX = c.x + targetDistanceRadius * cos(blipAngleRad).toFloat()
            val blipY = c.y - targetDistanceRadius * sin(blipAngleRad).toFloat()
            val blipCenter = Offset(blipX, blipY)

            // Pulsing target blip
            drawCircle(
                color = Color(currentZone.urgencyColorHex).copy(alpha = pulseAlpha * 0.4f),
                radius = 18f,
                center = blipCenter
            )
            drawCircle(
                color = Color(currentZone.urgencyColorHex),
                radius = 7f,
                center = blipCenter
            )
            drawCircle(
                color = Color.White,
                radius = 2.5f,
                center = blipCenter
            )

            // If Buzzer Command active: draw flashing acoustic ripples
            if (isBuzzerActive) {
                drawCircle(
                    color = TacticalCyan.copy(alpha = pulseAlpha),
                    radius = maxR * pulseAlpha,
                    center = c,
                    style = Stroke(width = 3f)
                )
            }

            // Center Rescuer Antennas
            drawCircle(color = TacticalCyan, radius = 5f, center = c)
        }

        // Concentric Zone Label Overlays
        Text(
            text = "< 2m EXTRACTION",
            color = UrgentCrimson,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .align(Alignment.Center)
                .offset(y = (-36).dp)
        )
        Text(
            text = "3 - 8m VOID",
            color = UrgentAmber,
            fontSize = 8.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier
                .align(Alignment.Center)
                .offset(y = (-78).dp)
        )
        Text(
            text = "10 - 15m DEBRIS",
            color = TextSecondary,
            fontSize = 8.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier
                .align(Alignment.Center)
                .offset(y = (-118).dp)
        )
    }
}

@Composable
fun PhysicalZoneTelemetryCard(
    currentZone: PhysicalDebrisZone,
    filteredEmaDbm: Float,
    rawRssiDbm: Float,
    estimatedMeters: Float,
    alpha: Float,
    onAlphaChange: (Float) -> Unit,
    pulseAlpha: Float
) {
    val zoneColor = Color(currentZone.urgencyColorHex)
    val isSurfaceExtraction = (currentZone == PhysicalDebrisZone.ZONE_SURFACE_EXTRACTION)

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = TacticalSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (isSurfaceExtraction) 2.dp else 1.dp,
                color = if (isSurfaceExtraction) UrgentCrimson.copy(alpha = pulseAlpha) else TacticalBorder,
                shape = RoundedCornerShape(14.dp)
            )
            .testTag("physical_zone_telemetry_card")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Zone Name & Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "PHYSICAL DEBRIS EXTRACTION ZONE",
                        color = TextSecondary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = currentZone.title,
                        color = zoneColor,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black
                    )
                }

                // Estimated Distance in large digits
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "%.1f m".format(estimatedMeters),
                        color = zoneColor,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "EST. PENETRATION",
                        color = TextMuted,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = currentZone.distanceDescription,
                color = TextSecondary,
                fontSize = 11.sp
            )

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = TacticalBorder)
            Spacer(modifier = Modifier.height(10.dp))

            // Signal Metrics: Filtered EMA vs Raw Decibels
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("FILTERED EMA SIGNAL:", color = TextSecondary, fontSize = 10.sp)
                    Text(
                        text = "%.1f dBm".format(filteredEmaDbm),
                        color = TacticalCyan,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("RAW RF BURST (2.4 GHz):", color = TextSecondary, fontSize = 10.sp)
                    Text(
                        text = "%.1f dBm".format(rawRssiDbm),
                        color = TextSecondary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Medium,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // EMA Smoothing Factor Slider
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Multipath EMA Alpha: %.2f".format(alpha),
                    color = TextSecondary,
                    fontSize = 11.sp,
                    modifier = Modifier.width(140.dp)
                )
                Slider(
                    value = alpha,
                    onValueChange = onAlphaChange,
                    valueRange = 0.05f..0.85f,
                    colors = SliderDefaults.colors(thumbColor = TacticalCyan, activeTrackColor = TacticalCyan),
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun SignalHistoryWaveform(history: List<Float>) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = TacticalSurfaceElevated),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = "REAL-TIME 2.4 GHz SIGNAL ATTENUATION HISTORY (EMA FILTERED)",
                color = TextSecondary,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
            ) {
                if (history.size < 2) return@Canvas
                val stepX = size.width / (history.size - 1).toFloat()
                val minDbm = -95f
                val maxDbm = -45f
                val range = maxDbm - minDbm

                val path = Path()
                history.forEachIndexed { index, dbm ->
                    val x = index * stepX
                    val normalizedY = 1f - ((dbm - minDbm) / range).coerceIn(0f, 1f)
                    val y = normalizedY * size.height
                    if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }

                drawPath(path = path, color = TacticalCyan, style = Stroke(width = 2.5f))
            }
        }
    }
}

@Composable
fun AcousticOpticalTriggerCard(
    isBuzzerActive: Boolean,
    secondsRemaining: Int,
    commandHex: String,
    pulseAlpha: Float,
    onTransmit: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = TacticalSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, if (isBuzzerActive) UrgentCrimson else TacticalBorder, RoundedCornerShape(14.dp))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.VolumeUp, contentDescription = "Alarm", tint = UrgentCrimson, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "AUTHENTICATED BLE TRIGGER (0xFFEE)",
                        color = UrgentCrimson,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                if (isBuzzerActive) {
                    Text(
                        text = "BURST: ${secondsRemaining}s REMAINING",
                        color = UrgentCrimson,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            Text(
                text = "Transmits an authenticated 0xFFEE command frame to trigger buried phone's internal buzzer at maximum gain & strobe camera LED for rescue canine search teams.",
                color = TextSecondary,
                fontSize = 11.sp,
                modifier = Modifier.padding(vertical = 6.dp)
            )

            if (isBuzzerActive) {
                // Visual Strobe Confirmation Pulse
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(UrgentCrimsonBg)
                        .padding(10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(UrgentCrimson.copy(alpha = pulseAlpha)))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "STROBE ACTIVE & MAX GAIN BUZZER FIRING",
                            color = UrgentCrimson,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            Button(
                onClick = onTransmit,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("btn_transmit_0xffee_trigger"),
                colors = ButtonDefaults.buttonColors(containerColor = UrgentCrimson)
            ) {
                Icon(imageVector = Icons.Default.Campaign, contentDescription = "Trigger", tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isBuzzerActive) "RE-TRIGGER 0xFFEE ACOUSTIC/OPTICAL BURST" else "TRIGGER PHONE BUZZER & CAMERA STROBE",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }

            if (commandHex.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Payload Transmitted: $commandHex",
                    color = TextMuted,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun AcousticGeigerRadarCard(
    acousticState: com.example.engine.audio.AcousticRadarState,
    onToggleEnabled: () -> Unit,
    onSetVolume: (Float) -> Unit,
    onToggleMute: () -> Unit,
    onTriggerPip: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("card_acoustic_geiger_radar"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (acousticState.isEnabled) Color(0x1A00E5FF) else TacticalCardBg
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (acousticState.isEnabled) CyanAccent else BorderStroke
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(if (acousticState.isEnabled) Color(0x3300E5FF) else TacticalDarkBg)
                            .border(1.dp, if (acousticState.isEnabled) CyanAccent else BorderStroke, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (acousticState.isEnabled) Icons.Default.Hearing else Icons.Default.HearingDisabled,
                            contentDescription = "Acoustic Geiger",
                            tint = if (acousticState.isEnabled) CyanAccent else TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "HANDS-FREE ACOUSTIC GEIGER RADAR",
                            color = TextPrimary,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "16-bit PCM AudioTrack • Smoke & Rubble Guidance",
                            color = TextSecondary,
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp
                        )
                    }
                }

                Switch(
                    checked = acousticState.isEnabled,
                    onCheckedChange = { onToggleEnabled() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.Black,
                        checkedTrackColor = CyanAccent
                    )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Scaling telemetry values
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = TacticalDarkBg),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderStroke)
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("SYNTH FREQ", color = TextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "${acousticState.currentFrequencyHz} Hz",
                            color = CyanAccent,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                        Text("800 to 2400 Hz", color = TextMuted, fontSize = 8.sp)
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = TacticalDarkBg),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderStroke)
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("PULSE INTERVAL", color = TextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "${acousticState.currentIntervalMs} ms",
                            color = YellowAlert,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                        Text("1800 to 100 ms", color = TextMuted, fontSize = 8.sp)
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = TacticalDarkBg),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderStroke)
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("CADENCE", color = TextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "${acousticState.beepsPerMinute} BPM",
                            color = if (acousticState.beepsPerMinute > 300) RedCritical else TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                        Text("Geiger Rate", color = TextMuted, fontSize = 8.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Volume & Test Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onToggleMute, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = if (acousticState.isMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                            contentDescription = "Mute",
                            tint = if (acousticState.isMuted) RedCritical else CyanAccent,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Text(
                        text = if (acousticState.isMuted) "MUTED" else "VOL ${(acousticState.volume * 100).toInt()}%",
                        color = TextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                OutlinedButton(
                    onClick = onTriggerPip,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp), tint = CyanAccent)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Test Pip", fontSize = 11.sp, color = CyanAccent)
                }
            }
        }
    }
}

