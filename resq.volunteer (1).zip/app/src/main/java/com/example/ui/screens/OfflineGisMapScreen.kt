package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BeaconEntity
import com.example.engine.gis.GisCompassVector
import com.example.engine.gis.MbtilesMetadata
import com.example.engine.gis.OsmVectorFeature
import com.example.ui.TriageViewModel
import com.example.ui.theme.*
import kotlin.math.*

@Composable
fun OfflineGisMapScreen(
    viewModel: TriageViewModel,
    modifier: Modifier = Modifier
) {
    val beacons by viewModel.rankedBeacons.collectAsState()
    val mbtilesGisState by viewModel.mbtilesGisState.collectAsState()
    val batteryState by viewModel.batteryState.collectAsState()

    val selectedSurvivor = mbtilesGisState.selectedSurvivor
    val threshold = batteryState.threshold
    val thresholdColor by animateColorAsState(targetValue = threshold.primaryColor, label = "thresholdColor")

    var zoomScale by remember { mutableStateOf(1.0f) }
    var panOffset by remember { mutableStateOf(Offset.Zero) }

    val transformState = rememberTransformableState { zoomChange, offsetChange, _ ->
        zoomScale = (zoomScale * zoomChange).coerceIn(0.6f, 3.5f)
        panOffset += offsetChange
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(TacticalDarkBg)
    ) {
        // 1. Entirely Offline GIS Vector Map Canvas (Loaded from regional_osm.mbtiles)
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .transformable(state = transformState)
                .pointerInput(beacons, panOffset, zoomScale) {
                    detectTapGestures { tapOffset ->
                        val centerW = size.width / 2f + panOffset.x
                        val centerH = size.height / 2f + panOffset.y
                        val coordScale = 45000f * zoomScale

                        var tappedBeacon: BeaconEntity? = null
                        var minDistance = 48f // 48px touch target

                        beacons.forEach { b ->
                            val dx = (b.longitude - mbtilesGisState.rescuerLon).toFloat() * coordScale
                            val dy = -(b.latitude - mbtilesGisState.rescuerLat).toFloat() * coordScale
                            val pinX = centerW + dx
                            val pinY = centerH + dy
                            val dist = hypot(tapOffset.x - pinX, tapOffset.y - pinY)
                            if (dist < minDistance) {
                                minDistance = dist
                                tappedBeacon = b
                            }
                        }

                        viewModel.mbtilesOfflineGisEngine.selectSurvivorMarker(tappedBeacon)
                        viewModel.offlineGisEngine.selectSurvivorMarker(tappedBeacon)
                    }
                }
                .testTag("offline_gis_canvas")
        ) {
            val canvasW = size.width
            val canvasH = size.height
            val center = Offset(canvasW / 2f + panOffset.x, canvasH / 2f + panOffset.y)
            val coordScale = 45000f * zoomScale

            // Draw Background Tactical Grid
            val gridSpacing = 60f * zoomScale
            var gx = (center.x % gridSpacing)
            while (gx < canvasW) {
                drawLine(
                    color = Color(0x1A263E54),
                    start = Offset(gx, 0f),
                    end = Offset(gx, canvasH),
                    strokeWidth = 1f
                )
                gx += gridSpacing
            }
            var gy = (center.y % gridSpacing)
            while (gy < canvasH) {
                drawLine(
                    color = Color(0x1A263E54),
                    start = Offset(0f, gy),
                    end = Offset(canvasW, gy),
                    strokeWidth = 1f
                )
                gy += gridSpacing
            }

            // Draw Sector Perimeter Boundaries (Alpha, Bravo, Charlie, Delta)
            drawRect(
                color = Color(0x15FF1744),
                topLeft = Offset(center.x - 220f * zoomScale, center.y - 180f * zoomScale),
                size = Size(200f * zoomScale, 200f * zoomScale)
            )
            drawRect(
                color = Color(0x40FF1744),
                topLeft = Offset(center.x - 220f * zoomScale, center.y - 180f * zoomScale),
                size = Size(200f * zoomScale, 200f * zoomScale),
                style = Stroke(width = 1.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f)))
            )

            // Draw Regional Vector Layers from pre-bundled regional_osm.mbtiles
            mbtilesGisState.vectorFeatures.forEach { feature ->
                val fx = center.x + (feature.centerLon - mbtilesGisState.rescuerLon).toFloat() * coordScale
                val fy = center.y - (feature.centerLat - mbtilesGisState.rescuerLat).toFloat() * coordScale
                val featureCenter = Offset(fx, fy)
                val rad = (feature.radiusMeters * 0.45f * zoomScale).coerceAtLeast(14f)

                when (feature.layer) {
                    "water" -> {
                        // Yamuna Floodplain Hazard Line
                        val floodPath = Path().apply {
                            moveTo(fx - rad * 1.5f, fy - rad * 2f)
                            quadraticBezierTo(fx, fy, fx + rad * 1.5f, fy + rad * 2.5f)
                            lineTo(canvasW, fy + rad * 2.5f)
                            lineTo(canvasW, fy - rad * 2f)
                            close()
                        }
                        drawPath(floodPath, color = Color(0x2200E5FF))
                    }
                    "building" -> {
                        // Commercial Structural Collapse Perimeter
                        drawRect(
                            color = Color(0x25FF1744),
                            topLeft = Offset(fx - rad, fy - rad),
                            size = Size(rad * 2, rad * 2)
                        )
                        drawRect(
                            color = Color(0x80FF1744),
                            topLeft = Offset(fx - rad, fy - rad),
                            size = Size(rad * 2, rad * 2),
                            style = Stroke(width = 1.5f)
                        )
                    }
                    "road" -> {
                        // Evacuation Corridor Line
                        drawLine(
                            color = Color(0x5500E676),
                            start = Offset(center.x - 120f * zoomScale, center.y + 160f * zoomScale),
                            end = featureCenter,
                            strokeWidth = 3f * zoomScale,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 10f))
                        )
                    }
                    "rubble" -> {
                        // Metro Tunnel Cavity
                        drawCircle(
                            color = Color(0x33FFA000),
                            radius = rad,
                            center = featureCenter
                        )
                        drawCircle(
                            color = Color(0xFFFFA000),
                            radius = rad,
                            center = featureCenter,
                            style = Stroke(width = 1.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f)))
                        )
                    }
                    "base_post" -> {
                        // NDRF Incident Command Base
                        drawCircle(
                            color = Color(0xFF00E5FF),
                            radius = 12f * zoomScale,
                            center = featureCenter,
                            style = Stroke(width = 2.5f)
                        )
                    }
                }
            }

            // Draw Direct Bearing Line to Selected Survivor (if selected)
            if (selectedSurvivor != null) {
                val tx = center.x + (selectedSurvivor.longitude - mbtilesGisState.rescuerLon).toFloat() * coordScale
                val ty = center.y - (selectedSurvivor.latitude - mbtilesGisState.rescuerLat).toFloat() * coordScale
                val targetOffset = Offset(tx, ty)

                drawLine(
                    color = TacticalCyan,
                    start = center,
                    end = targetOffset,
                    strokeWidth = 2.5f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f))
                )

                // Pulse circle at target
                drawCircle(
                    color = TacticalCyan.copy(alpha = 0.3f),
                    radius = 24f * zoomScale,
                    center = targetOffset
                )
            }

            // Draw Color-Coded Triage Pins
            beacons.forEach { beacon ->
                val px = center.x + (beacon.longitude - mbtilesGisState.rescuerLon).toFloat() * coordScale
                val py = center.y - (beacon.latitude - mbtilesGisState.rescuerLat).toFloat() * coordScale
                val pinCenter = Offset(px, py)

                val pinColor = when (beacon.triageLevelCode) {
                    1 -> UrgentCrimson
                    2 -> UrgentAmber
                    else -> SafeGreen
                }

                // Halo ring
                drawCircle(
                    color = pinColor.copy(alpha = 0.25f),
                    radius = 16f * zoomScale,
                    center = pinCenter
                )
                // Solid core pin
                drawCircle(
                    color = pinColor,
                    radius = 7.5f * zoomScale,
                    center = pinCenter
                )
                // White center point
                drawCircle(
                    color = Color.White,
                    radius = 2.5f * zoomScale,
                    center = pinCenter
                )

                // Selected marker ring
                if (beacon.hash == selectedSurvivor?.hash) {
                    drawCircle(
                        color = Color.White,
                        radius = 22f * zoomScale,
                        center = pinCenter,
                        style = Stroke(width = 2f)
                    )
                }
            }

            // Rescuer Core Blue Dot with Heading Beam
            val heading = mbtilesGisState.rescuerHeadingDegrees
            rotate(degrees = heading, pivot = center) {
                // Heading vision cone
                val visionPath = Path().apply {
                    moveTo(center.x, center.y)
                    lineTo(center.x - 24f * zoomScale, center.y - 65f * zoomScale)
                    lineTo(center.x + 24f * zoomScale, center.y - 65f * zoomScale)
                    close()
                }
                drawPath(visionPath, color = TacticalCyan.copy(alpha = 0.22f))
            }

            // Rescuer core dot
            drawCircle(
                color = thresholdColor,
                radius = 8f * zoomScale,
                center = center
            )
            drawCircle(
                color = Color.White,
                radius = 3f * zoomScale,
                center = center
            )
        }

        // 2. Offline MBTiles Map Header & Navigation Controls
        TacticalMbtilesControlOverlay(
            metadata = mbtilesGisState.metadata,
            threshold = threshold,
            thresholdColor = thresholdColor,
            zoomScale = zoomScale,
            onZoomIn = { zoomScale = (zoomScale * 1.25f).coerceAtMost(3.5f) },
            onZoomOut = { zoomScale = (zoomScale / 1.25f).coerceAtLeast(0.6f) },
            onRecenter = {
                zoomScale = 1.0f
                panOffset = Offset.Zero
            },
            onOpenBattery = { viewModel.openBatteryDutyCycleDialog() }
        )

        // 3. Emergency Operational Sheet (When a Triage Pin is selected)
        if (selectedSurvivor != null) {
            EmergencyMbtilesOperationalSheet(
                survivor = selectedSurvivor,
                compassVector = mbtilesGisState.compassVector,
                thresholdColor = thresholdColor,
                onClose = { viewModel.mbtilesOfflineGisEngine.selectSurvivorMarker(null) },
                onLaunchRubbleRadar = { viewModel.navigateToRubbleRadarFor(selectedSurvivor) },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
            )
        }
    }
}

@Composable
fun TacticalMbtilesControlOverlay(
    metadata: MbtilesMetadata,
    threshold: com.example.engine.battery.SurvivalThreshold,
    thresholdColor: Color,
    zoomScale: Float,
    onZoomIn: () -> Unit,
    onZoomOut: () -> Unit,
    onRecenter: () -> Unit,
    onOpenBattery: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp)
    ) {
        // MBTiles Local Vector Storage Indicator Card
        Card(
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = TacticalSurface.copy(alpha = 0.94f)),
            border = androidx.compose.foundation.BorderStroke(1.dp, thresholdColor.copy(alpha = 0.6f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Layers,
                            contentDescription = "GIS",
                            tint = TacticalCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "OFFLINE GIS: ${metadata.name}",
                            color = TacticalCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(threshold.containerColor)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "AIR-GAPPED .MBTILES",
                            color = thresholdColor,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "Format: ${metadata.format.uppercase()} Vector • ${metadata.totalTilesCount} Regional Tiles • Zoom ${metadata.minZoom}-${metadata.maxZoom} • Local Assets",
                    color = TextSecondary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Map Legend Floating Row
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.padding(horizontal = 2.dp)
        ) {
            LegendPill("Level 1 Entrapment", UrgentCrimson)
            LegendPill("Level 2 Medical", UrgentAmber)
            LegendPill("Level 3 Supply", SafeGreen)
        }

        Spacer(modifier = Modifier.weight(1f))

        // Zoom & Recenter Floating Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                SmallFloatingActionButton(
                    onClick = onZoomIn,
                    containerColor = TacticalSurfaceElevated,
                    contentColor = TextPrimary,
                    modifier = Modifier.testTag("btn_gis_zoom_in")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Zoom In")
                }
                SmallFloatingActionButton(
                    onClick = onZoomOut,
                    containerColor = TacticalSurfaceElevated,
                    contentColor = TextPrimary,
                    modifier = Modifier.testTag("btn_gis_zoom_out")
                ) {
                    Icon(imageVector = Icons.Default.Remove, contentDescription = "Zoom Out")
                }
                SmallFloatingActionButton(
                    onClick = onRecenter,
                    containerColor = TacticalCyan,
                    contentColor = Color(0xFF00363D),
                    modifier = Modifier.testTag("btn_gis_recenter")
                ) {
                    Icon(imageVector = Icons.Default.MyLocation, contentDescription = "Recenter")
                }
            }
        }
    }
}

@Composable
fun LegendPill(title: String, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(TacticalSurface.copy(alpha = 0.85f))
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(7.dp).clip(CircleShape).background(color))
            Spacer(modifier = Modifier.width(4.dp))
            Text(title, color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun EmergencyMbtilesOperationalSheet(
    survivor: BeaconEntity,
    compassVector: GisCompassVector,
    thresholdColor: Color,
    onClose: () -> Unit,
    onLaunchRubbleRadar: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .padding(12.dp)
            .testTag("emergency_operational_sheet"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = TacticalSurface),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, thresholdColor.copy(alpha = 0.7f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Sheet Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = survivor.survivorId,
                            color = TextPrimary,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(
                                    when (survivor.triageLevelCode) {
                                        1 -> UrgentCrimsonBg
                                        2 -> UrgentAmberBg
                                        else -> SafeGreenBg
                                    }
                                )
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = survivor.triageLevel.label,
                                color = when (survivor.triageLevelCode) {
                                    1 -> UrgentCrimson
                                    2 -> UrgentAmber
                                    else -> SafeGreen
                                },
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Text(
                        text = "${survivor.survivorCount} ${if (survivor.survivorCount > 1) "Survivors" else "Survivor"} • ${survivor.sector}",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }

                IconButton(onClick = onClose) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = TacticalBorder)
            Spacer(modifier = Modifier.height(10.dp))

            // Offline Magnetic Compass Vector Display
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Compass Rose Canvas (Visual Bearing Dial)
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(TacticalSurfaceElevated)
                        .border(1.5.dp, TacticalBorder, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val c = center
                        val r = size.minDimension / 2f

                        // Draw North Tick
                        drawLine(
                            color = UrgentCrimson,
                            start = Offset(c.x, c.y - r + 4f),
                            end = Offset(c.x, c.y - r + 14f),
                            strokeWidth = 2.5f
                        )

                        // Target Bearing Arrow
                        rotate(degrees = compassVector.targetBearingDegrees - compassVector.rescuerHeadingDegrees, pivot = c) {
                            val arrowPath = Path().apply {
                                moveTo(c.x, c.y - r + 16f)
                                lineTo(c.x - 6f, c.y - r + 28f)
                                lineTo(c.x + 6f, c.y - r + 28f)
                                close()
                            }
                            drawPath(arrowPath, color = TacticalCyan)
                            drawLine(
                                color = TacticalCyan,
                                start = c,
                                end = Offset(c.x, c.y - r + 24f),
                                strokeWidth = 2.5f
                            )
                        }

                        // Center pin
                        drawCircle(color = Color.White, radius = 3f, center = c)
                    }
                }

                Spacer(modifier = Modifier.width(14.dp))

                // Heading Guidance & Distance
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "MAGNETIC COMPASS VECTOR",
                        color = TacticalCyan,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "${compassVector.distanceMeters.toInt()} METERS",
                        color = TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "Target Bearing: %03d° %s".format(
                            compassVector.targetBearingDegrees.toInt(),
                            compassVector.cardinalDirection
                        ),
                        color = TextSecondary,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    val headingText = when {
                        compassVector.isAlignedWithinFiveDegrees -> "ON BEARING: ADVANCE FORWARD"
                        compassVector.headingDeltaDegrees > 0 -> "TURN RIGHT %d°".format(compassVector.headingDeltaDegrees.toInt())
                        else -> "TURN LEFT %d°".format(abs(compassVector.headingDeltaDegrees).toInt())
                    }
                    val headingColor = if (compassVector.isAlignedWithinFiveDegrees) SafeGreen else UrgentAmber

                    Text(
                        text = headingText,
                        color = headingColor,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Raw Coordinates & Attributes
            Text(
                text = "GPS: %.6f° N, %.6f° E • Alt: %.1fm • Batt: %d%%".format(
                    survivor.latitude,
                    survivor.longitude,
                    survivor.altitudeMeters,
                    survivor.batteryPercent
                ),
                color = TextSecondary,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = "Network Path: ${survivor.relayNodeName} (${survivor.hopCount} hops) • Hash: ${survivor.hash.take(12)}...",
                color = TextMuted,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Launch Rubble Radar Button
            Button(
                onClick = onLaunchRubbleRadar,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .testTag("btn_sheet_launch_rubble_radar"),
                colors = ButtonDefaults.buttonColors(containerColor = UrgentCrimson)
            ) {
                Icon(imageVector = Icons.Default.Radar, contentDescription = "Radar", tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "ACTIVATE RUBBLE RADAR (2.4 GHz MICRO-LOCALIZATION)",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
        }
    }
}
