package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BeaconEntity
import com.example.engine.OfflineGisEngine
import com.example.model.RescueStatus
import com.example.model.TriageLevel
import com.example.ui.TriageViewModel
import com.example.ui.theme.*

@Composable
fun TriageDashboardScreen(
    viewModel: TriageViewModel,
    modifier: Modifier = Modifier
) {
    val beacons by viewModel.rankedBeacons.collectAsState()
    val filterState by viewModel.filterState.collectAsState()
    val bleState by viewModel.bleState.collectAsState()
    val gisState by viewModel.gisState.collectAsState()
    val batteryState by viewModel.batteryState.collectAsState()

    val level1Count = remember(beacons) { beacons.count { it.triageLevelCode == 1 } }
    val level2Count = remember(beacons) { beacons.count { it.triageLevelCode == 2 } }
    val level3Count = remember(beacons) { beacons.count { it.triageLevelCode == 3 } }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TacticalDarkBg)
    ) {
        // 1. QoS Engine Priority Header Banner
        QoSPrioritySummaryBanner(
            level1Count = level1Count,
            level2Count = level2Count,
            level3Count = level3Count,
            activeForwardingCount = bleState.activeMultiHopBroadcasts.size,
            isScanning = bleState.isScanning,
            onToggleScanning = { viewModel.bleScanningEngine.toggleScanning() }
        )

        // 1.5. Hardware Battery Survival Threshold Strip
        HardwareSurvivalStrip(
            batteryState = batteryState,
            onClick = { viewModel.openBatteryDutyCycleDialog() }
        )

        // 2. Active Multi-Hop Re-Broadcast Notification (if packets forwarding for 15s)
        if (bleState.activeMultiHopBroadcasts.isNotEmpty()) {
            MultiHopForwardingBanner(broadcasts = bleState.activeMultiHopBroadcasts)
        }

        // 3. Instant Filter Chips Row (Urgency, Sector, Trapped)
        TriageFilterChipsRow(
            filterState = filterState,
            onSelectLevel = { viewModel.setFilterLevel(it) },
            onSelectSector = { viewModel.setFilterSector(it) },
            onToggleTrapped = { viewModel.toggleOnlyTrapped() },
            onToggleClusters = { viewModel.toggleOnlyClusters() }
        )

        // 4. Ranked Triage Incident Cards
        if (beacons.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.SearchOff,
                        contentDescription = "No Beacons",
                        tint = TextSecondary,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "NO SURVIVOR BEACONS IN CURRENT SECTOR FILTER",
                        color = TextSecondary,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "BLE Scanning engine is continuously listening for 30-byte 0xFFFF frames",
                        color = TextMuted,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
                    .padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                items(beacons, key = { it.hash }) { beacon ->
                    TriageCard(
                        beacon = beacon,
                        rescuerLat = gisState.rescuerLat,
                        rescuerLon = gisState.rescuerLon,
                        onUpdateStatus = { newStatus ->
                            viewModel.updateRescueStatus(beacon.hash, newStatus)
                        },
                        onNavigateToRadar = { viewModel.navigateToRubbleRadarFor(beacon) },
                        onNavigateToGis = { viewModel.navigateToGisFor(beacon) }
                    )
                }
            }
        }
    }
}

@Composable
fun QoSPrioritySummaryBanner(
    level1Count: Int,
    level2Count: Int,
    level3Count: Int,
    activeForwardingCount: Int,
    isScanning: Boolean,
    onToggleScanning: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .testTag("qos_priority_banner"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = TacticalSurface)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (isScanning) TacticalCyan else UrgentCrimson)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "INCIDENT COMMAND QoS ENGINE",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = TacticalCyan,
                        letterSpacing = 1.sp
                    )
                }
                AssistChip(
                    onClick = onToggleScanning,
                    label = {
                        Text(
                            text = if (isScanning) "BLE SCAN: ACTIVE" else "BLE SCAN: PAUSED",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isScanning) TacticalCyan else UrgentAmber
                        )
                    },
                    modifier = Modifier.height(28.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // QoS Priority Counters: Level 1 Preempts All
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Level 1: Preempts all
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(UrgentCrimsonBg)
                        .border(1.dp, UrgentCrimson, RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = "Critical",
                                tint = UrgentCrimson,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("LEVEL 1", color = UrgentCrimson, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Text("$level1Count", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Black)
                        Text("PREEMPTIVE", color = UrgentCrimson, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
                    }
                }

                // Level 2: Medical
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(UrgentAmberBg)
                        .border(1.dp, UrgentAmber, RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.MedicalServices,
                                contentDescription = "Medical",
                                tint = UrgentAmber,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("LEVEL 2", color = UrgentAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Text("$level2Count", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Black)
                        Text("MEDICAL", color = UrgentAmber, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
                    }
                }

                // Level 3: Supplies
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(SafeGreenBg)
                        .border(1.dp, SafeGreen, RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Inventory2,
                                contentDescription = "Supply",
                                tint = SafeGreen,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("LEVEL 3", color = SafeGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Text("$level3Count", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Black)
                        Text("SUPPLIES", color = SafeGreen, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

@Composable
fun HardwareSurvivalStrip(
    batteryState: com.example.engine.battery.BatteryMonitorState,
    onClick: () -> Unit
) {
    val threshold = batteryState.threshold
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 2.dp)
            .clickable { onClick() }
            .testTag("hardware_survival_strip"),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = threshold.containerColor),
        border = androidx.compose.foundation.BorderStroke(1.dp, threshold.borderColor)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (batteryState.isCharging) Icons.Default.BatteryChargingFull else Icons.Default.BatteryStd,
                    contentDescription = "Battery",
                    tint = threshold.primaryColor,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "POWER: ${threshold.label} (${batteryState.activePercentage}%)",
                    color = threshold.primaryColor,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black
                )
                if (batteryState.isDutyCycleActive) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFFFF1744))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = if (batteryState.isDeepSleeping) "DEEP SLEEP 15M" else "WAKE 30S",
                            color = Color.White,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = if (batteryState.isDutyCycleActive) "Duty Cycling Active >" else "Manage Power >",
                    color = threshold.primaryColor,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun MultiHopForwardingBanner(broadcasts: List<com.example.engine.ActiveForwardingBroadcast>) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = TacticalSurfaceElevated)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Sensors,
                    contentDescription = "Forwarding",
                    tint = TacticalCyan,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "MULTI-HOP FORWARDING ENGINE (15s Re-Broadcast Active)",
                    color = TacticalCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            broadcasts.forEach { b ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Bridging coverage: ${b.survivorId} (TTL: ${b.ttlRemaining}, Hops: ${b.hopCount})",
                        color = TextPrimary,
                        fontSize = 12.sp
                    )
                    Text(
                        text = "${b.secondsRemaining}s left",
                        color = UrgentAmber,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun TriageFilterChipsRow(
    filterState: com.example.ui.DashboardFilterState,
    onSelectLevel: (TriageLevel?) -> Unit,
    onSelectSector: (String?) -> Unit,
    onToggleTrapped: () -> Unit,
    onToggleClusters: () -> Unit
) {
    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) {
        // Priority Level Chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            item {
                FilterChip(
                    selected = filterState.selectedTriageLevel == null,
                    onClick = { onSelectLevel(null) },
                    label = { Text("All Urgencies", fontSize = 11.sp) },
                    modifier = Modifier.testTag("filter_level_all")
                )
            }
            item {
                FilterChip(
                    selected = filterState.selectedTriageLevel == TriageLevel.LEVEL_1,
                    onClick = { onSelectLevel(if (filterState.selectedTriageLevel == TriageLevel.LEVEL_1) null else TriageLevel.LEVEL_1) },
                    label = { Text("Level 1 (Critical)", fontSize = 11.sp, color = UrgentCrimson) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = UrgentCrimsonBg),
                    modifier = Modifier.testTag("filter_level_1")
                )
            }
            item {
                FilterChip(
                    selected = filterState.selectedTriageLevel == TriageLevel.LEVEL_2,
                    onClick = { onSelectLevel(if (filterState.selectedTriageLevel == TriageLevel.LEVEL_2) null else TriageLevel.LEVEL_2) },
                    label = { Text("Level 2 (Medical)", fontSize = 11.sp, color = UrgentAmber) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = UrgentAmberBg),
                    modifier = Modifier.testTag("filter_level_2")
                )
            }
            item {
                FilterChip(
                    selected = filterState.selectedTriageLevel == TriageLevel.LEVEL_3,
                    onClick = { onSelectLevel(if (filterState.selectedTriageLevel == TriageLevel.LEVEL_3) null else TriageLevel.LEVEL_3) },
                    label = { Text("Level 3 (Supply)", fontSize = 11.sp, color = SafeGreen) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = SafeGreenBg),
                    modifier = Modifier.testTag("filter_level_3")
                )
            }
            item {
                FilterChip(
                    selected = filterState.onlyTrapped,
                    onClick = onToggleTrapped,
                    label = { Text("Trapped Only", fontSize = 11.sp) },
                    modifier = Modifier.testTag("filter_trapped_only")
                )
            }
            item {
                FilterChip(
                    selected = filterState.onlyClusters,
                    onClick = onToggleClusters,
                    label = { Text("Clusters (3+)", fontSize = 11.sp) },
                    modifier = Modifier.testTag("filter_clusters_only")
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Sector Organization Chips
        val sectors = listOf("All", "Sector Alpha", "Sector Bravo", "Sector Charlie", "Sector Delta")
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(sectors) { sec ->
                val isSelected = (sec == "All" && filterState.selectedSector == null) || filterState.selectedSector == sec
                InputChip(
                    selected = isSelected,
                    onClick = { onSelectSector(if (sec == "All") null else sec) },
                    label = { Text(sec, fontSize = 11.sp) },
                    modifier = Modifier.testTag("filter_sector_$sec")
                )
            }
        }
    }
}

@Composable
fun TriageCard(
    beacon: BeaconEntity,
    rescuerLat: Double,
    rescuerLon: Double,
    onUpdateStatus: (RescueStatus) -> Unit,
    onNavigateToRadar: () -> Unit,
    onNavigateToGis: () -> Unit
) {
    val distanceMeters = remember(beacon.latitude, beacon.longitude, rescuerLat, rescuerLon) {
        OfflineGisEngine.calculateHaversineDistance(rescuerLat, rescuerLon, beacon.latitude, beacon.longitude).toInt()
    }

    val elapsedMinutes = remember(beacon.receivedAtMillis) {
        val diffMs = System.currentTimeMillis() - beacon.receivedAtMillis
        (diffMs / 60000).coerceAtLeast(0)
    }

    val urgencyColor = when (beacon.triageLevelCode) {
        1 -> UrgentCrimson
        2 -> UrgentAmber
        else -> SafeGreen
    }

    val borderColor = when (beacon.triageLevelCode) {
        1 -> UrgentCrimson.copy(alpha = 0.6f)
        2 -> UrgentAmber.copy(alpha = 0.4f)
        else -> TacticalBorder
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, borderColor, RoundedCornerShape(14.dp))
            .testTag("triage_card_${beacon.survivorId}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = TacticalSurface)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // 1. Header: Urgency Level Badge, Victim ID, Battery, RSSI
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(urgencyColor.copy(alpha = 0.2f))
                            .border(1.dp, urgencyColor, RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = beacon.triageLevel.label,
                            color = urgencyColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = beacon.survivorId,
                        color = TextPrimary,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Battery and RSSI
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.BatteryChargingFull,
                        contentDescription = "Battery",
                        tint = if (beacon.batteryPercent < 25) UrgentCrimson else TextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "${beacon.batteryPercent}%",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(start = 2.dp, end = 8.dp)
                    )
                    Text(
                        text = "${beacon.rssi} dBm",
                        color = TacticalCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 2. Vital Situational Data Row: Survivor Count & Trauma Flags
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Survivor cluster badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(TacticalSurfaceElevated)
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Groups,
                            contentDescription = "Individuals",
                            tint = if (beacon.survivorCount >= 3) UrgentCrimson else TacticalCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${beacon.survivorCount} ${if (beacon.survivorCount > 1) "PEOPLE" else "PERSON"}",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Sector badge
                Text(
                    text = beacon.sector,
                    color = TextSecondary,
                    fontSize = 12.sp,
                    maxLines = 1
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Trauma Flags Flow / Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (beacon.isTrappedUnderRubble) {
                    TraumaChip("TRAPPED RUBBLE", UrgentCrimson, Icons.Default.Hardware)
                }
                if (beacon.hasSevereHemorrhage) {
                    TraumaChip("SEVERE BLEED", UrgentCrimson, Icons.Default.Bloodtype)
                }
                if (beacon.isClusterThreePlus) {
                    TraumaChip("CLUSTER 3+", UrgentAmber, Icons.Default.GroupAdd)
                }
                if (beacon.isInsulinDepleted) {
                    TraumaChip("INSULIN LOW", UrgentAmber, Icons.Default.Medication)
                }
                if (beacon.isOxygenDepleted) {
                    TraumaChip("OXYGEN LOW", UrgentAmber, Icons.Default.Air)
                }
                if (beacon.isStrandedSupply) {
                    TraumaChip("FOOD/WATER NEEDED", SafeGreen, Icons.Default.WaterDrop)
                }
                if (beacon.requiresCanineSearch) {
                    TraumaChip("CANINE SEARCH", TacticalCyan, Icons.Default.Pets)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = TacticalBorder)
            Spacer(modifier = Modifier.height(10.dp))

            // 3. Situational Coordinates & Network Hops
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Place,
                            contentDescription = "Coords",
                            tint = TacticalCyan,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "%.4f° N, %.4f° E".format(beacon.latitude, beacon.longitude),
                            color = TextPrimary,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = " (Alt: %.1fm)".format(beacon.altitudeMeters),
                            color = if (beacon.altitudeMeters < 0) UrgentCrimson else TextSecondary,
                            fontSize = 11.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Route,
                            contentDescription = "Route",
                            tint = TextSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (beacon.hopCount == 0) "Direct reception (0 hops)" else "${beacon.relayNodeName} (${beacon.hopCount} hops)",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "$distanceMeters m away",
                        color = TacticalCyan,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (elapsedMinutes == 0L) "Just now" else "${elapsedMinutes}m ago",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 4. Rescue Status Selector & Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Status Dropdown / Cycle button
                var statusMenuExpanded by remember { mutableStateOf(false) }
                Box {
                    OutlinedButton(
                        onClick = { statusMenuExpanded = true },
                        modifier = Modifier
                            .height(36.dp)
                            .testTag("btn_status_${beacon.survivorId}"),
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) {
                        Text(
                            text = beacon.rescueStatus.label,
                            fontSize = 11.sp,
                            color = when (beacon.rescueStatus) {
                                RescueStatus.UNASSIGNED -> TextSecondary
                                RescueStatus.TRIAGE_EN_ROUTE -> UrgentAmber
                                RescueStatus.EXTRACTED -> SafeGreen
                                RescueStatus.EVACUATED -> TacticalCyan
                            }
                        )
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = "Change Status",
                            tint = TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = statusMenuExpanded,
                        onDismissRequest = { statusMenuExpanded = false }
                    ) {
                        RescueStatus.values().forEach { status ->
                            DropdownMenuItem(
                                text = { Text(status.label, fontSize = 12.sp) },
                                onClick = {
                                    onUpdateStatus(status)
                                    statusMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.weight(1f))

                // Action: Navigate GIS & Compass
                OutlinedButton(
                    onClick = onNavigateToGis,
                    modifier = Modifier
                        .height(36.dp)
                        .testTag("btn_navigate_gis_${beacon.survivorId}"),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TacticalCyan),
                    contentPadding = PaddingValues(horizontal = 10.dp)
                ) {
                    Icon(imageVector = Icons.Default.Navigation, contentDescription = "Compass", modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("GIS BEARING", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                // Action: Rubble Radar
                Button(
                    onClick = onNavigateToRadar,
                    modifier = Modifier
                        .height(36.dp)
                        .testTag("btn_rubble_radar_${beacon.survivorId}"),
                    colors = ButtonDefaults.buttonColors(containerColor = UrgentCrimson),
                    contentPadding = PaddingValues(horizontal = 10.dp)
                ) {
                    Icon(imageVector = Icons.Default.Radar, contentDescription = "Radar", modifier = Modifier.size(14.dp), tint = Color.White)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("RUBBLE RADAR", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }
    }
}

@Composable
fun TraumaChip(label: String, color: Color, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(color.copy(alpha = 0.15f))
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = icon, contentDescription = label, tint = color, modifier = Modifier.size(11.dp))
            Spacer(modifier = Modifier.width(3.dp))
            Text(label, color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
    }
}
