package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.*

@Composable
fun InjectBeaconDialog(
    onDismiss: () -> Unit,
    onInject: (
        survivorCount: Int,
        isTrapped: Boolean,
        hasSevereBleed: Boolean,
        isInsulinLow: Boolean,
        isOxygenLow: Boolean,
        isStrandedSupply: Boolean,
        sector: String
    ) -> Unit
) {
    var count by remember { mutableStateOf(1) }
    var isTrapped by remember { mutableStateOf(true) }
    var hasSevereBleed by remember { mutableStateOf(false) }
    var isInsulinLow by remember { mutableStateOf(false) }
    var isOxygenLow by remember { mutableStateOf(false) }
    var isStrandedSupply by remember { mutableStateOf(false) }
    var selectedSector by remember { mutableStateOf("Sector Alpha (Collapsed Plaza)") }

    val sectors = listOf(
        "Sector Alpha (Collapsed Plaza)",
        "Sector Bravo (Riverbank Void)",
        "Sector Charlie (Metro Tunnel)",
        "Sector Delta (Residential)"
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("inject_beacon_dialog"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = TacticalSurface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Text(
                    text = "INJECT BLE TEST BEACON (0xFFFF)",
                    style = MaterialTheme.typography.titleMedium,
                    color = TacticalCyan,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Simulates an incoming 30-byte connectionless emergency frame into the BLE engine & SQLite deduplication pipeline.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                )

                // Survivor Count
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Survivor Count:", color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        FilledTonalButton(
                            onClick = { if (count > 1) count-- },
                            modifier = Modifier.testTag("btn_count_minus")
                        ) { Text("-") }
                        Text(
                            text = "$count",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                        FilledTonalButton(
                            onClick = { if (count < 10) count++ },
                            modifier = Modifier.testTag("btn_count_plus")
                        ) { Text("+") }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = TacticalBorder)
                Spacer(modifier = Modifier.height(12.dp))

                Text("Trauma & Urgency Flags (QoS Level Engine):", color = TextSecondary, style = MaterialTheme.typography.labelMedium)

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = isTrapped,
                        onCheckedChange = { isTrapped = it },
                        colors = CheckboxDefaults.colors(checkedColor = UrgentCrimson)
                    )
                    Text("Trapped Under Rubble (Level 1)", color = if (isTrapped) UrgentCrimson else TextPrimary, style = MaterialTheme.typography.bodyMedium)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = hasSevereBleed,
                        onCheckedChange = { hasSevereBleed = it },
                        colors = CheckboxDefaults.colors(checkedColor = UrgentCrimson)
                    )
                    Text("Severe Hemorrhaging (Level 1)", color = if (hasSevereBleed) UrgentCrimson else TextPrimary, style = MaterialTheme.typography.bodyMedium)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = isInsulinLow,
                        onCheckedChange = { isInsulinLow = it },
                        colors = CheckboxDefaults.colors(checkedColor = UrgentAmber)
                    )
                    Text("Insulin Depletion (Level 2)", color = if (isInsulinLow) UrgentAmber else TextPrimary, style = MaterialTheme.typography.bodyMedium)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = isOxygenLow,
                        onCheckedChange = { isOxygenLow = it },
                        colors = CheckboxDefaults.colors(checkedColor = UrgentAmber)
                    )
                    Text("Oxygen Depletion (Level 2)", color = if (isOxygenLow) UrgentAmber else TextPrimary, style = MaterialTheme.typography.bodyMedium)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = isStrandedSupply,
                        onCheckedChange = { isStrandedSupply = it },
                        colors = CheckboxDefaults.colors(checkedColor = SafeGreen)
                    )
                    Text("Stranded Supply / Water (Level 3)", color = if (isStrandedSupply) SafeGreen else TextPrimary, style = MaterialTheme.typography.bodyMedium)
                }

                Spacer(modifier = Modifier.height(12.dp))
                Text("Target Sector:", color = TextSecondary, style = MaterialTheme.typography.labelMedium)
                sectors.forEach { sec ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(vertical = 2.dp)
                    ) {
                        RadioButton(
                            selected = (selectedSector == sec),
                            onClick = { selectedSector = sec },
                            colors = RadioButtonDefaults.colors(selectedColor = TacticalCyan)
                        )
                        Text(sec, color = TextPrimary, style = MaterialTheme.typography.bodySmall)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss, modifier = Modifier.testTag("btn_cancel_inject")) {
                        Text("CANCEL", color = TextSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            onInject(count, isTrapped, hasSevereBleed, isInsulinLow, isOxygenLow, isStrandedSupply, selectedSector)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = TacticalCyan),
                        modifier = Modifier.testTag("btn_confirm_inject")
                    ) {
                        Text("BROADCAST PAYLOAD", color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
