package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.BeaconEntity
import com.example.data.TriageDatabase
import com.example.data.TriageRepository
import com.example.engine.BleScanEngineState
import com.example.engine.BleScanningEngine
import com.example.engine.DataMuleEngine
import com.example.engine.DataMuleEngineState
import com.example.engine.OfflineGisEngine
import com.example.engine.OfflineGisState
import com.example.engine.RubbleRadarEngine
import com.example.engine.RubbleRadarState
import com.example.engine.audio.AcousticRadarAudioEngine
import com.example.engine.audio.AcousticRadarState
import com.example.engine.battery.BatteryMonitorState
import com.example.engine.battery.HardwareBatteryMonitor
import com.example.engine.battery.SurvivalThreshold
import com.example.engine.gis.MbtilesGisState
import com.example.engine.gis.MbtilesOfflineGisEngine
import com.example.model.RescueStatus
import com.example.model.TriageLevel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class ConsoleTab(val title: String, val badge: String = "") {
    TRIAGE_DASHBOARD("Triage QoS"),
    OFFLINE_GIS("Tactical GIS"),
    RUBBLE_RADAR("Rubble Radar"),
    DATA_MULE("Data Mule P2P")
}

data class DashboardFilterState(
    val selectedTriageLevel: TriageLevel? = null,
    val selectedSector: String? = null,
    val onlyTrapped: Boolean = false,
    val onlyClusters: Boolean = false,
    val searchQuery: String = ""
)

class TriageViewModel(application: Application) : AndroidViewModel(application) {
    private val database = TriageDatabase.getDatabase(application)
    private val repository = TriageRepository(database.beaconDao(), database.dataMuleDao())

    // Core Operational Engines
    val bleScanningEngine = BleScanningEngine(repository, viewModelScope)
    val rubbleRadarEngine = RubbleRadarEngine(application, viewModelScope)
    val offlineGisEngine = OfflineGisEngine(application, viewModelScope)
    val dataMuleEngine = DataMuleEngine(repository, viewModelScope)

    // Newly Requested Production Capabilities
    val hardwareBatteryMonitor = HardwareBatteryMonitor(application, viewModelScope)
    val acousticRadarAudioEngine = AcousticRadarAudioEngine(viewModelScope)
    val mbtilesOfflineGisEngine = MbtilesOfflineGisEngine(application, viewModelScope)

    // State Flows
    val bleState: StateFlow<BleScanEngineState> = bleScanningEngine.state
    val radarState: StateFlow<RubbleRadarState> = rubbleRadarEngine.state
    val gisState: StateFlow<OfflineGisState> = offlineGisEngine.state
    val dataMuleState: StateFlow<DataMuleEngineState> = dataMuleEngine.state

    val batteryState: StateFlow<BatteryMonitorState> = hardwareBatteryMonitor.state
    val acousticState: StateFlow<AcousticRadarState> = acousticRadarAudioEngine.state
    val mbtilesGisState: StateFlow<MbtilesGisState> = mbtilesOfflineGisEngine.state

    private val _currentTab = MutableStateFlow(ConsoleTab.TRIAGE_DASHBOARD)
    val currentTab: StateFlow<ConsoleTab> = _currentTab.asStateFlow()

    private val _filterState = MutableStateFlow(DashboardFilterState())
    val filterState: StateFlow<DashboardFilterState> = _filterState.asStateFlow()

    private val _showInjectBeaconDialog = MutableStateFlow(false)
    val showInjectBeaconDialog: StateFlow<Boolean> = _showInjectBeaconDialog.asStateFlow()

    private val _showBatteryDutyCycleDialog = MutableStateFlow(false)
    val showBatteryDutyCycleDialog: StateFlow<Boolean> = _showBatteryDutyCycleDialog.asStateFlow()

    private val _showAcousticRadarDialog = MutableStateFlow(false)
    val showAcousticRadarDialog: StateFlow<Boolean> = _showAcousticRadarDialog.asStateFlow()

    // Processed and QoS-ranked beacons
    val rankedBeacons: StateFlow<List<BeaconEntity>> = combine(
        repository.allBeacons,
        _filterState
    ) { beacons, filter ->
        var list = beacons

        // Sector filter
        if (!filter.selectedSector.isNullOrBlank() && filter.selectedSector != "All") {
            list = list.filter { it.sector.contains(filter.selectedSector, ignoreCase = true) }
        }

        // Triage QoS filter
        if (filter.selectedTriageLevel != null) {
            list = list.filter { it.triageLevel == filter.selectedTriageLevel }
        }

        // Specific trauma filters
        if (filter.onlyTrapped) {
            list = list.filter { it.isTrappedUnderRubble }
        }
        if (filter.onlyClusters) {
            list = list.filter { it.survivorCount >= 3 || it.isClusterThreePlus }
        }

        if (filter.searchQuery.isNotBlank()) {
            val q = filter.searchQuery.trim().lowercase()
            list = list.filter {
                it.survivorId.lowercase().contains(q) ||
                        it.sector.lowercase().contains(q) ||
                        it.relayNodeName.lowercase().contains(q)
            }
        }

        // QoS Strict Urgency Ranking:
        // Level 1 preempts Level 2, Level 2 preempts Level 3.
        // Secondary: survivor count descending, then distance / freshness.
        list.sortedWith(
            compareBy<BeaconEntity> { it.triageLevelCode }
                .thenByDescending { it.survivorCount }
                .thenByDescending { it.receivedAtMillis }
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val syncLogs = repository.allSyncLogs.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    init {
        viewModelScope.launch {
            repository.seedInitialDisasterTelemetryIfEmpty()
        }

        // Link Rubble Radar RSSI directly to Acoustic Proximity Audio Engine
        viewModelScope.launch {
            radarState.collect { rState ->
                val rssi = rState.filteredEmaDbm.toInt()
                acousticRadarAudioEngine.updateLiveRssi(rssi)
            }
        }

        // Sync Duty Cycle state with radio activity
        viewModelScope.launch {
            batteryState.collect { bState ->
                if (bState.isDutyCycleActive && bState.isDeepSleeping) {
                    if (bleScanningEngine.state.value.isScanning) {
                        bleScanningEngine.stopScanning()
                    }
                } else if (bState.isDutyCycleActive && bState.isAwakeBurst) {
                    if (!bleScanningEngine.state.value.isScanning) {
                        bleScanningEngine.startContinuousScanning()
                    }
                }
            }
        }
    }

    fun setTab(tab: ConsoleTab) {
        _currentTab.value = tab
    }

    fun setFilterLevel(level: TriageLevel?) {
        _filterState.value = _filterState.value.copy(selectedTriageLevel = level)
    }

    fun setFilterSector(sector: String?) {
        _filterState.value = _filterState.value.copy(selectedSector = sector)
    }

    fun toggleOnlyTrapped() {
        _filterState.value = _filterState.value.copy(onlyTrapped = !_filterState.value.onlyTrapped)
    }

    fun toggleOnlyClusters() {
        _filterState.value = _filterState.value.copy(onlyClusters = !_filterState.value.onlyClusters)
    }

    fun setSearchQuery(query: String) {
        _filterState.value = _filterState.value.copy(searchQuery = query)
    }

    fun updateRescueStatus(hash: String, status: RescueStatus) {
        viewModelScope.launch {
            repository.updateRescueStatus(hash, status)
        }
    }

    fun navigateToRubbleRadarFor(beacon: BeaconEntity) {
        rubbleRadarEngine.selectTargetSurvivor(beacon)
        acousticRadarAudioEngine.updateLiveRssi(beacon.rssi)
        _currentTab.value = ConsoleTab.RUBBLE_RADAR
    }

    fun navigateToGisFor(beacon: BeaconEntity) {
        offlineGisEngine.selectSurvivorMarker(beacon)
        mbtilesOfflineGisEngine.selectSurvivorMarker(beacon)
        _currentTab.value = ConsoleTab.OFFLINE_GIS
    }

    fun openInjectDialog() {
        _showInjectBeaconDialog.value = true
    }

    fun closeInjectDialog() {
        _showInjectBeaconDialog.value = false
    }

    fun openBatteryDutyCycleDialog() {
        _showBatteryDutyCycleDialog.value = true
    }

    fun closeBatteryDutyCycleDialog() {
        _showBatteryDutyCycleDialog.value = false
    }

    fun openAcousticRadarDialog() {
        _showAcousticRadarDialog.value = true
    }

    fun closeAcousticRadarDialog() {
        _showAcousticRadarDialog.value = false
    }

    fun injectSimulatedBeacon(
        survivorCount: Int,
        isTrapped: Boolean,
        hasSevereBleed: Boolean,
        isInsulinLow: Boolean,
        isOxygenLow: Boolean,
        isStrandedSupply: Boolean,
        sector: String
    ) {
        bleScanningEngine.injectSimulatedBeacon(
            survivorCount = survivorCount,
            isTrapped = isTrapped,
            hasSevereBleed = hasSevereBleed,
            isInsulinLow = isInsulinLow,
            isOxygenLow = isOxygenLow,
            isStrandedSupply = isStrandedSupply,
            sectorName = sector
        )
        closeInjectDialog()
    }

    override fun onCleared() {
        super.onCleared()
        offlineGisEngine.unregisterCompassSensor()
        mbtilesOfflineGisEngine.unregisterCompassSensor()
        hardwareBatteryMonitor.unregister()
        acousticRadarAudioEngine.release()
        bleScanningEngine.stopScanning()
        rubbleRadarEngine.stopTracking()
    }
}
