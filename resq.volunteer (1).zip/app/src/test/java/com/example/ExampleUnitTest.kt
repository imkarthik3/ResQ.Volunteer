package com.example

import com.example.engine.audio.AcousticRadarAudioEngine
import com.example.engine.battery.SurvivalThreshold
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun `test survival threshold categorization`() {
        // Emerald Green: >= 50%
        assertEquals(SurvivalThreshold.EMERALD_GREEN, SurvivalThreshold.fromBatteryPercentage(100))
        assertEquals(SurvivalThreshold.EMERALD_GREEN, SurvivalThreshold.fromBatteryPercentage(75))
        assertEquals(SurvivalThreshold.EMERALD_GREEN, SurvivalThreshold.fromBatteryPercentage(50))

        // Warning Amber: 20-49%
        assertEquals(SurvivalThreshold.WARNING_AMBER, SurvivalThreshold.fromBatteryPercentage(49))
        assertEquals(SurvivalThreshold.WARNING_AMBER, SurvivalThreshold.fromBatteryPercentage(35))
        assertEquals(SurvivalThreshold.WARNING_AMBER, SurvivalThreshold.fromBatteryPercentage(20))

        // Critical Red: < 20%
        assertEquals(SurvivalThreshold.CRITICAL_RED, SurvivalThreshold.fromBatteryPercentage(19))
        assertEquals(SurvivalThreshold.CRITICAL_RED, SurvivalThreshold.fromBatteryPercentage(10))
        assertEquals(SurvivalThreshold.CRITICAL_RED, SurvivalThreshold.fromBatteryPercentage(0))
    }

    @Test
    fun `test acoustic radar geiger continuous scaling laws`() {
        // At -85 dBm: 800 Hz and 1800 ms interval
        val freqAt85 = AcousticRadarAudioEngine.calculateFrequencyForRssi(-85)
        val intervalAt85 = AcousticRadarAudioEngine.calculateIntervalForRssi(-85)
        assertEquals(800, freqAt85)
        assertEquals(1800L, intervalAt85)

        // At -50 dBm: 2400 Hz and 100 ms interval
        val freqAt50 = AcousticRadarAudioEngine.calculateFrequencyForRssi(-50)
        val intervalAt50 = AcousticRadarAudioEngine.calculateIntervalForRssi(-50)
        assertEquals(2400, freqAt50)
        assertEquals(100L, intervalAt50)

        // Midpoint around -68 dBm
        val freqMid = AcousticRadarAudioEngine.calculateFrequencyForRssi(-68)
        val intervalMid = AcousticRadarAudioEngine.calculateIntervalForRssi(-68)
        assertTrue("Frequency should scale smoothly: $freqMid", freqMid in 1400..1800)
        assertTrue("Interval should scale smoothly: $intervalMid", intervalMid in 700..1100)

        // Values worse than -85 dBm are clamped to minimums
        assertEquals(800, AcousticRadarAudioEngine.calculateFrequencyForRssi(-95))
        assertEquals(1800L, AcousticRadarAudioEngine.calculateIntervalForRssi(-95))

        // Values closer than -50 dBm are clamped to maximums
        assertEquals(2400, AcousticRadarAudioEngine.calculateFrequencyForRssi(-40))
        assertEquals(100L, AcousticRadarAudioEngine.calculateIntervalForRssi(-40))
    }
}
