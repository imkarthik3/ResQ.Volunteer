package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.engine.OfflineGisEngine
import com.example.model.BeaconPacket
import com.example.model.TraumaFlags
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Rescuer Console", appName)
    }

    @Test
    fun `test 30 byte BLE payload encoding and decoding`() {
        val packet = BeaconPacket(
            survivorId = "VIC-8841",
            survivorCount = 3,
            flags = TraumaFlags(
                isTrappedUnderRubble = true,
                hasSevereHemorrhage = true,
                isClusterThreePlus = true
            ),
            latitude = 28.6139,
            longitude = 77.2090,
            altitudeMeters = -3.5f,
            ttl = 4,
            hopCount = 0,
            timestampSeconds = 1716000000L,
            batteryPercent = 65,
            relayNodeName = "Direct",
            rssi = -68
        )

        val rawBytes = BeaconPacket.encode(packet)
        assertEquals(30, rawBytes.size)

        // Check magic bytes 0xFFFF
        assertEquals(0xFF.toByte(), rawBytes[0])
        assertEquals(0xFF.toByte(), rawBytes[1])

        val decoded = BeaconPacket.decode(rawBytes, rssi = -68, relayOrigin = "Direct")
        assertNotNull(decoded)
        assertEquals(3, decoded!!.survivorCount)
        assertTrue(decoded.flags.isTrappedUnderRubble)
        assertTrue(decoded.flags.hasSevereHemorrhage)
        assertEquals(4, decoded.ttl)
        assertEquals(0, decoded.hopCount)
    }

    @Test
    fun `test distance calculation and bearing`() {
        val lat1 = 28.6135
        val lon1 = 77.2085
        val lat2 = 28.6140
        val lon2 = 77.2090

        val distance = OfflineGisEngine.calculateHaversineDistance(lat1, lon1, lat2, lon2)
        assertTrue(distance > 50f && distance < 150f)

        val bearing = OfflineGisEngine.calculateBearing(lat1, lon1, lat2, lon2)
        assertTrue(bearing in 0f..90f) // North-East
    }
}
